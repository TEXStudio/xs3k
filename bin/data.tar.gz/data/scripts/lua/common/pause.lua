--this file uses components IDs from [14000 to 15000[ and tabindices from [1300 to 1400[

local pauseContainer = CreateFrame("container", "pauseContainer", 14000)
pauseContainer:SetSize(1.8, 1.4)
pauseContainer:SetPosition(0.1, 0.3)
pauseContainer:Renderable(true)
pauseContainer:RenderBorder(true)
--pauseContainer:SetBackgroundColour(0.0, 0.0, 0.0, 0.8)
pauseContainer:SetBackgroundColour(0.0, 0.0, 0.0, 0.8)
pauseContainer:SetBorderColour(0.0, 0.0, 0.0, 0.0)

local pauseContainerGlobalImage = CreateFrame("image", "pauseContainerGlobalImage", 14100, 14100)
pauseContainerGlobalImage:SetSize(pauseContainer:GetSize())
pauseContainerGlobalImage:SetPosition(0.0, 0.0)
pauseContainer:Attach(pauseContainerGlobalImage)

local pauseLabel = CreateFrame("label", "pauseLabel", 14200, 1)
pauseLabel:SetText("- PAUSED -")
pauseLabel:SetSize(select(1, pauseContainer:GetSize()), 0.1)
--pauseLabel:SetPosition(0.0, (select(2, pauseContainer:GetSize()) - select(2, pauseLabel:GetSize()))/2)
pauseLabel:SetPosition(0.0, select(2, pauseContainer:GetSize()) - 2*select(2, pauseLabel:GetSize()))
pauseLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
pauseContainer:Attach(pauseLabel)


local pauseBackToMenuContainer = CreateFrame("container", "pauseBackToMenuContainer", 14001)
pauseBackToMenuContainer:SetSize(0.6, 0.3)
pauseBackToMenuContainer:SetPosition((select(1, pauseContainer:GetSize())-select(1, pauseBackToMenuContainer:GetSize()))/2.0, 0.35)
local pauseBackToMenuImageUp = CreateFrame("image", "pauseBackToMenuImageUp", 14101, 14101)
pauseBackToMenuImageUp:SetPosition(0.0, 0.0)
pauseBackToMenuImageUp:SetSize(pauseBackToMenuContainer:GetSize())
local pauseBackToMenuImageOver = CreateFrame("image", "pauseBackToMenuImageOver", 14102, 14102)
pauseBackToMenuImageOver:SetPosition(0.0, 0.0)
pauseBackToMenuImageOver:SetSize(pauseBackToMenuContainer:GetSize())
pauseBackToMenuImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local pauseBackToMenuButton = CreateFrame("button", "pauseBackToMenuButton", 14300)
pauseBackToMenuButton:TabIndex(1300)
pauseBackToMenuButton:SetSize(pauseBackToMenuContainer:GetSize())
pauseBackToMenuButton:SetPosition(0.0, 0.0)
pauseBackToMenuButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
pauseBackToMenuButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
pauseBackToMenuContainer:Attach(pauseBackToMenuButton)
pauseBackToMenuContainer:Attach(pauseBackToMenuImageUp)
pauseBackToMenuContainer:Attach(pauseBackToMenuImageOver)
pauseContainer:Attach(pauseBackToMenuContainer)


pauseMenuButtonCycleStart = { 0.0, 0.0, 0.0, 0.0 }
pauseMenuButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
pauseMenuButtonCycleDoAnimation = { false, false, false, false }
pauseMenuButtonCycleAnimationOver = { false, false, false, false }


pauseBackToMenuButton:EventFunction(function(self, e, ...)
	buttonOver(e, 1, pauseMenuButtonCycleStart, pauseMenuButtonCycleDuration, pauseMenuButtonCycleDoAnimation, pauseMenuButtonCycleAnimationOver, pauseBackToMenuImageOver)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		score_player_finished = 0
		scoreContainer:Visible(true)
		TriggerEvent(SCENE_QUIT)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, scoreBackToMenuButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

rank1bestTime = 9999
rank2bestTime = 9999
rank3bestTime = 9999

pauseContainer:EventFunction(function(self, e, ...)
	if e == SCENE_ISPAUSED then
		--TODO play a pause sound
		if cursorWidgetImage ~= nil then cursorWidgetImage:Visible(true) end
		pauseContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, pauseBackToMenuButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	elseif e == SCENE_ISRESUMED then
		if cursorWidgetImage ~= nil then cursorWidgetImage:Visible(false) end
		TriggerEvent(COMPONENT_REQUEST_FOCUS_PREVIOUS)
		--TODO play a resume sound
		pauseContainer:Visible(false)
	elseif e == SEND_SCORES then
		print("send scores:", ...)
		firstHighscoreNameLabel:SetText("1. " .. select(4, ...))
		rank1bestTime = select(1, ...)
		rank2bestTime = select(2, ...)
		rank3bestTime = select(3, ...)

		local minutes, seconds, remainingMilliseconds = formatMilliseconds(rank1bestTime)
		local secondsPadding = ""
		if seconds < 0 then seconds = 0
		elseif seconds < 10 then secondsPadding = "0" end
		firstHighscoreTimeLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
		
		secondsPadding = ""
		minutes, seconds, remainingMilliseconds = formatMilliseconds(rank2bestTime)
		if seconds < 0 then seconds = 0
		elseif seconds < 10 then secondsPadding = "0" end
		secondHighscoreNameLabel:SetText("2. " .. select(5, ...))
		secondHighscoreTimeLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)

		secondsPadding = ""
		minutes, seconds, remainingMilliseconds = formatMilliseconds(rank3bestTime)
		if seconds < 0 then seconds = 0
		elseif seconds < 10 then secondsPadding = "0" end
		thirdHighscoreNameLabel:SetText("3. " .. select(6, ...))
		thirdHighscoreTimeLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
	end
end)  


pauseContainer:Visible(false)
UIRoot:Attach(pauseContainer, 10)
