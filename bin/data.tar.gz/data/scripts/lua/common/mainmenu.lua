print(_VERSION,"\n")--just for debug purpose so we know when the script are actually (re)loaded
--this file uses components IDs from [998 to 2000[ and tabindices from [1 to 100[

local gameStuffContainer = CreateFrame("container", "gameStuffContainer", 999)
gameStuffContainer:SetPosition(0.0, 0.0)
gameStuffContainer:SetSize(2.0, 2.0)
UIRoot:Attach(gameStuffContainer, 5)

local menuUIStuffContainer = CreateFrame("container", "menuUIStuffContainer", 998)
menuUIStuffContainer:SetPosition(0.0, 0.0)
menuUIStuffContainer:SetSize(2.0, 2.0)
UIRoot:Attach(menuUIStuffContainer, 1)

local menuContainer = CreateFrame("container", "menuContainer", 1000)
menuContainer:SetPosition(0.0, 0.1)
menuContainer:SetSize(2.0, 1.9)


local font1 = CreateFont(1, "font1")
--font1:SetSpacing(0.015, 0.0)
font1:SetSpacing(0.0175, 0.0)
local font2 = CreateFont(2, "font2")
font2:SetSpacing(0.02, 0.0)
local font3 = CreateFont(3, "font3")
font3:SetSpacing(0.0175, 0.0)


local menuBackgroundImage1 = CreateFrame("image", "menuBackgroundImage1", 1295, 1295) --clouds
menuBackgroundImage1:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage1:SetPosition(0.0, -0.1)
menuBackgroundImage1:SetSize(2.0, 2.0)
menuContainer:Attach(menuBackgroundImage1)
local menuBackgroundImage2 = CreateFrame("image", "menuBackgroundImage2", 1294, 1294) --mountains
menuBackgroundImage2:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage2:SetPosition(0.0, -0.1)
menuBackgroundImage2:SetSize(2.0, 2.0)
menuContainer:Attach(menuBackgroundImage2)
--[[
local menuBackgroundImage3 = CreateFrame("image", "menuBackgroundImage3", 1293, 1293) --snow
menuBackgroundImage3:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage3:SetPosition(0.0, -0.1)
menuBackgroundImage3:SetSize(2.0, 2.0)
menuContainer:Attach(menuBackgroundImage3)
]]
local menuBackgroundImage3 = CreateFrame("image", "menuBackgroundImage3", 1292, 1292) --tree
menuBackgroundImage3:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage3:SetPosition(0.0, -0.1)
menuBackgroundImage3:SetSize(2.0, 2.0)
menuContainer:Attach(menuBackgroundImage3)
local menuBackgroundImage4 = CreateFrame("image", "menuBackgroundImage4", 1291, 1291)
menuBackgroundImage4:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage4:SetPosition(0.0, -0.225)
menuBackgroundImage4:SetSize(2.0, 2.0/6.0)
menuContainer:Attach(menuBackgroundImage4)
local menuBackgroundImage5 = CreateFrame("image", "menuBackgroundImage5", 1290, 1290)
menuBackgroundImage5:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage5:SetPosition(0.0, -0.1)
menuBackgroundImage5:SetSize(2.0, 2.0/6.0)
menuContainer:Attach(menuBackgroundImage5)
local menuBackgroundImage6 = CreateFrame("image", "menuBackgroundImage6", 1289, 1289)
menuBackgroundImage6:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
menuBackgroundImage6:SetPosition(0.0, 0.05)
menuBackgroundImage6:SetSize(2.0, 2.0/6.0)
menuContainer:Attach(menuBackgroundImage6)

--flip example
--local menuBackgroundImage1 = CreateFrame("image", "menuBackgroundImage1", 1291, 1291, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0)



local titleImage = CreateFrame("image", "titleImage", 1299, 1299)
titleImage:SetPosition(0.1, 1.50)
titleImage:SetSize(1.8, 0.5)
menuUIStuffContainer:Attach(titleImage)
local titleImage2 = CreateFrame("image", "titleImage2", 1296, 1296)
titleImage2:SetPosition(0.1, 1.50)
titleImage2:SetSize(1.8, 0.5)
menuUIStuffContainer:Attach(titleImage2)
titleImage2:Visible(true)


local timeTrialContainer = CreateFrame("container", "timeTrialContainer", 1001)
timeTrialContainer:SetPosition(0.75, 1.1)
timeTrialContainer:SetSize(0.5, 0.25)
local timeTrialImageUp = CreateFrame("image", "timeTrialImageUp", 1300, 1300)
timeTrialImageUp:SetPosition(0.0, 0.0)
timeTrialImageUp:SetSize(timeTrialContainer:GetSize())
local timeTrialImageOver = CreateFrame("image", "timeTrialImageOver", 1301, 1301)
timeTrialImageOver:SetPosition(0.0, 0.0)
timeTrialImageOver:SetSize(timeTrialContainer:GetSize())
timeTrialImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 1.0)
local timeTrialButton = CreateFrame("button", "timeTrialButton", 1200)
timeTrialButton:TabIndex(1)
timeTrialButton:SetPosition(0.0, 0.0)
timeTrialButton:SetSize(timeTrialContainer:GetSize())
timeTrialButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
timeTrialButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
timeTrialContainer:Attach(timeTrialButton)
timeTrialContainer:Attach(timeTrialImageUp)
timeTrialContainer:Attach(timeTrialImageOver)
menuContainer:Attach(timeTrialContainer)


local versusContainer = CreateFrame("container", "versusContainer", 1002)
versusContainer:SetPosition(0.75, 0.8)
versusContainer:SetSize(timeTrialContainer:GetSize())
local versusImageUp = CreateFrame("image", "versusImageUp", 1302, 1302)
versusImageUp:SetPosition(0.0, 0.0)
versusImageUp:SetSize(versusContainer:GetSize())
local versusImageOver = CreateFrame("image", "versusImageOver", 1303, 1303)
versusImageOver:SetPosition(0.0, 0.0)
versusImageOver:SetSize(versusContainer:GetSize())
versusImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local versusButton = CreateFrame("button", "versusButton", 1201)
versusButton:TabIndex(2)
versusButton:SetPosition(0.0, 0.0)
versusButton:SetSize(versusContainer:GetSize())
versusButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
versusButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
versusContainer:Attach(versusButton)
versusContainer:Attach(versusImageUp)
versusContainer:Attach(versusImageOver)
menuContainer:Attach(versusContainer)


local optionsContainer = CreateFrame("container", "optionsContainer", 1003)
optionsContainer:SetPosition(0.75, 0.5)
optionsContainer:SetSize(timeTrialContainer:GetSize())
local optionsImageUp = CreateFrame("image", "optionsImageUp", 1304, 1304)
optionsImageUp:SetPosition(0.0, 0.0)
optionsImageUp:SetSize(optionsContainer:GetSize())
local optionsImageOver = CreateFrame("image", "optionsImageOver", 1305, 1305)
optionsImageOver:SetPosition(0.0, 0.0)
optionsImageOver:SetSize(optionsContainer:GetSize())
optionsImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local optionsButton = CreateFrame("button", "optionsButton", 1202)
optionsButton:TabIndex(3)
optionsButton:SetPosition(0.0, 0.0)
optionsButton:SetSize(optionsContainer:GetSize())
optionsButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
optionsContainer:Attach(optionsButton)
optionsContainer:Attach(optionsImageUp)
optionsContainer:Attach(optionsImageOver)
menuContainer:Attach(optionsContainer)


local creditsContainer = CreateFrame("container", "creditsContainer", 1005)
creditsContainer:SetPosition(0.75,  0.2)
creditsContainer:SetSize(timeTrialContainer:GetSize())
local creditsImageUp = CreateFrame("image", "creditsImageUp", 1308, 1308)
creditsImageUp:SetPosition(0.0, 0.0)
creditsImageUp:SetSize(creditsContainer:GetSize())
local creditsImageOver = CreateFrame("image", "creditsImageOver", 1309, 1309)
creditsImageOver:SetPosition(0.0, 0.0)
creditsImageOver:SetSize(creditsContainer:GetSize())
creditsImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local creditsButton = CreateFrame("button", "creditsButton", 1204)
creditsButton:TabIndex(4)
creditsButton:SetPosition(0.0, 0.0)
creditsButton:SetSize(creditsContainer:GetSize())
creditsButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
creditsButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
creditsContainer:Attach(creditsButton)
creditsContainer:Attach(creditsImageUp)
creditsContainer:Attach(creditsImageOver)
menuContainer:Attach(creditsContainer)


local exitContainer = CreateFrame("container", "exitContainer", 1004)
exitContainer:SetPosition(0.75,  -0.1)
exitContainer:SetSize(timeTrialContainer:GetSize())
local exitImageUp = CreateFrame("image", "exitImageUp", 1306, 1306)
exitImageUp:SetPosition(0.0, 0.0)
exitImageUp:SetSize(exitContainer:GetSize())
local exitImageOver = CreateFrame("image", "exitImageOver", 1307, 1307)
exitImageOver:SetPosition(0.0, 0.0)
exitImageOver:SetSize(exitContainer:GetSize())
exitImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local exitButton = CreateFrame("button", "exitButton", 1203)
exitButton:TabIndex(5)
exitButton:SetPosition(0.0, 0.0)
exitButton:SetSize(exitContainer:GetSize())
exitButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
exitButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
exitContainer:Attach(exitButton)
exitContainer:Attach(exitImageUp)
exitContainer:Attach(exitImageOver)
menuContainer:Attach(exitContainer)



menuUIStuffContainer:Visible(false)
menuContainer:Visible(false)
gameStuffContainer:Visible(false)
UIRoot:Attach(menuContainer)

options_state = {}
options_state["resolution"] = tonumber(CURRENT_RESOLUTION_VALUE)
options_state["quality"] = tonumber(CURRENT_QUALITY_VALUE)
options_state["music"] = tonumber(CURRENT_MUSIC_VALUE)
options_state["sound"] = tonumber(CURRENT_SOUND_VALUE)
if CURRENT_FULLSCREEN_VALUE > 0 then
	options_state["fullscreen"] = true
else
	options_state["fullscreen"] = false
end

--note that these things are 1-based
options_resolutions = {}
options_qualities = {"LOW", "HIGH"}
nextAndBackDistance = 0.025



for i = 1,RESOLUTIONS_COUNT do
	options_resolutions[i] = _G["RESOLUTION"..(i-1).."WIDTH"] .. "x" .. _G["RESOLUTION"..(i-1).."HEIGHT"]
end

race_types = {RACETYPE_PROPERTY_SOLO, RACETYPE_PROPERTY_VERSUS}
--map_types = {COURSETYPE_PROPERTY_SNOW, COURSETYPE_PROPERTY_ICE, COURSETYPE_PROPERTY_DESERT}
difficulty_types = {DIFFICULTY_PROPERTY_EASY, DIFFICULTY_PROPERTY_HARD}
species = {SPECIES_PROPERTY_DOG, SPECIES_PROPERTY_MOUSE, SPECIES_PROPERTY_DINO}

--the real min value is 0.5 but by using a slightly smaller value, the math is slightly easier for my animalSelection bar widths
min_e_value = 0.4
max_e_value = 1.5
min_d_value = 0.4
max_d_value = 1.5
min_m_value = 0.4
max_m_value = 1.5


--data sent from c++ that come from an NCF1 file
animals = {}
animals[species[1]] = {}
animals[species[2]] = {}
animals[species[3]] = {}

pack_test = {}


for _,v in ipairs(species) do 
	for j = 0, ANIMAL_INDIVIDUALS_COUNT-1 do
		local str = v..j.."NAME"
		animals[v][j] = {}
		
		pack_test[_G[str]] = 0
		animals[v][j]["NAME"] = _G[str]
		str = v..j.."E"
		animals[v][j]["E"] = _G[str]
		str = v..j.."D"
		animals[v][j]["D"] = _G[str]
		str = v..j.."M"
		animals[v][j]["M"] = _G[str]
	end
end


animal_state = {}
animal_state["specy"] = species[1]
animal_state["pack"] = {}
animalPackIsComplete = false
animalSelectionNextHasFocus = false
played_go = false

individuals_top_index = tonumber(0)


--this will be sent to the c++ game logic before starting the race
game_state = {}
game_state["playername"] = "noname"
game_state["racetype"] = race_types[1]
--game_state["course"] = map_types[1]
game_state["specy"] = animal_state["specy"]
game_state["pack"] = animal_state["pack"]
game_state["difficulty"] = difficulty_types[1]

game_state["course"] = {}
game_state["course"]["audioid"] = 103
game_state["course"]["groundid"] = 96
game_state["course"]["data"] = ""
game_state["course"]["scenerystart"] = 200
game_state["course"]["godmode"] = 0

previous_music_volume = tonumber(CURRENT_MUSIC_VALUE)
previous_sound_volume = tonumber(CURRENT_SOUND_VALUE)

buttonAnimationCycleDuration = 250

function swapImages(e, UP, OVER)
	if e == COMPONENT_ON_FOCUS_GAINED or e == COMPONENT_ON_MOUSE_HOVER then
		UP:Visible(false)
		OVER:Visible(true)
	elseif e == COMPONENT_ON_FOCUS_LOST or e == COMPONENT_ON_MOUSE_OUT then
		UP:Visible(true)
		OVER:Visible(false)
	end	
end

function playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		TriggerEvent(PLAY_OnClick)
	elseif e == COMPONENT_ON_FOCUS_GAINED or e == COMPONENT_ON_MOUSE_HOVER then
		TriggerEvent(PLAY_OverClick)
	end
end

local menuBgImgUShift = {
	{ 0.0 , 0.0 },
	{ 0.0 , 0.0 },
	{ 0.0 , 0.0 },
	{ 0.0 , 0.0 },
	{ 0.0 , 0.0 },
	{ 0.0 , 0.0 },
--	{ 0.0 , 0.0 },
}

--these are fractions of second
local menuBgImgUShiftAmount = {
	-1.0, -- clouds
	-1.0, -- mountains
--	1.5, -- snow
	-1.5, -- trees
	4.33, --bottom sled
	5.33, --middle sled
	3.33, --top sled
}

local menuBgImgUShiftLast = 0
local framerate = 30*1000 --milliseconds

menuBackgroundImage1:EventFunction(function( self, e , ... )
	local t = time("mlsec")
	local diff = (t - menuBgImgUShiftLast)
	local modifier = diff/framerate

	for i = 1, 6 do
		menuBgImgUShift[i][1] = menuBgImgUShift[i][1] - modifier*menuBgImgUShiftAmount[i]
		menuBgImgUShift[i][2] = menuBgImgUShift[i][2] - modifier*menuBgImgUShiftAmount[i]

		if menuBgImgUShift[i][1] < -1.0 then
			menuBgImgUShift[i][1] = menuBgImgUShift[i][1] + 1.0
		end

		if menuBgImgUShift[i][2] < -1.0 then
			menuBgImgUShift[i][2] = menuBgImgUShift[i][2] + 1.0
		end

		_G["menuBackgroundImage"..i]:SetUShift(menuBgImgUShift[i][1],menuBgImgUShift[i][2])
	end

	menuBgImgUShiftLast = t
end)


local titleCycleStart = 0
local titleCycleDuration = 4000
titleImage:EventFunction(function( self, e , ... )
	local t = time("mlsec")

	local totalTime = t - titleCycleStart

	if totalTime > titleCycleDuration then
		titleCycleStart = t
	end

	local fraction = totalTime/titleCycleDuration --off and gradually on
	fraction = 1 - math.abs(1 - (2 * fraction)) --pulse effect
	--fraction = 1 - fraction --on and gradually off
	titleImage2:SetBackgroundColour(0.0, 0.0, 0.0, fraction)
end)


menuContainer:EventFunction(function( self, e , ... )
	if e == BACK_TO_MENU or e == END_SPLASH1 then
		menuContainer:Visible(true)
		menuUIStuffContainer:Visible(true)
		gameStuffContainer:Visible(false)
		--splash1Container:Visible(false)
		--splash2Container:Visible(false)
		if cursorWidgetImage ~= nil then cursorWidgetImage:Visible(true) end
		scoreContainer:Visible(false)
		pauseContainer:Visible(false)

		--reset stuff
		disableOthersSpecies(1)
		individuals_top_index = 0
		animal_state["specy"] = species[1]
		recompute_edm_width()
		--selectYourAnimalLabel:SetText("Select Your 4 Animals")
		animalsInPackLabel:SetText(animalsInPackText.."0")
		selectYourAnimalLabel:SetText("Select Your 4 Animals")
		animalPackIsComplete = false
		animalSelectionNextHasFocus = false
		animalSelectionNextContainer:Visible(false)
		played_go = false
		animal_state["pack"] = {}
		game_state["specy"] = animal_state["specy"]
		game_state["pack"] = animal_state["pack"]
		TriggerEvent(COMPONENT_REQUEST_FOCUS, timeTrialButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)



function buttonOver(e, tableIdx, cycleStartTable, cycleDurationTable, cycleDoAnimationTable, cycleAnimationOverTable, img)
	if e == COMPONENT_ON_FOCUS_GAINED then
		cycleDoAnimationTable[tableIdx] = true
		cycleStartTable[tableIdx] = time("mlsec")
		cycleAnimationOverTable[tableIdx] = false
		img:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
	elseif e == COMPONENT_ON_FOCUS_LOST then
		cycleAnimationOverTable[tableIdx] = true
		cycleDoAnimationTable[tableIdx] = false
		img:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
	end

	if cycleDoAnimationTable[tableIdx] and not cycleAnimationOverTable[tableIdx] then
		local t = time("mlsec")

		local fraction = (t-cycleStartTable[tableIdx])/(cycleDurationTable[tableIdx]) --off and gradually on
		img:SetBackgroundColour(0.0, 0.0, 0.0, fraction)
		if t >= cycleStartTable[tableIdx] + cycleDurationTable[tableIdx] then
			cycleAnimationOverTable[tableIdx] = true
		end
	end
end

mainMenuButtonCycleStart = { 0.0, 0.0, 0.0, 0.0, 0.0 }
mainMenuButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
mainMenuButtonCycleDoAnimation = { false, false, false, false, false }
mainMenuButtonCycleAnimationOver = { false, false, false, false, false }

timeTrialButton:EventFunction(function( self, e , ... )
	buttonOver(e, 1, mainMenuButtonCycleStart, mainMenuButtonCycleDuration, mainMenuButtonCycleDoAnimation, mainMenuButtonCycleAnimationOver, timeTrialImageOver)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		game_state["racetype"] = race_types[1]
		menuContainer:Visible(false)
		--TODO: reactivate these 2 lines and common the last ones
		trackContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, trackSelectionPreviousTrackButton:GetId()+UIMANAGER_FROM_LUA_BIAS)


		--[[
		animalSelectionContainer:Visible(false)
		menuUIStuffContainer:Visible(false)
		gameStuffContainer:Visible(true)
		if cursorWidgetImage ~= nil then cursorWidgetImage:Visible(false) end
		TriggerEvent(FETCH_MENU_PARAMS, "noname", "solo", "snow", "dogs", "Benji", "Dave", "Maya", "Rover", "easy")	
		]]
	end
end)

versusButton:EventFunction(function( self, e , ... )
	buttonOver(e, 2, mainMenuButtonCycleStart, mainMenuButtonCycleDuration, mainMenuButtonCycleDoAnimation, mainMenuButtonCycleAnimationOver, versusImageOver)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		game_state["racetype"] = race_types[2]
		menuContainer:Visible(false)
		difficultySelectionContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, difficultySelectionEasyButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

optionsButton:EventFunction(function( self, e , ... )
	buttonOver(e, 3, mainMenuButtonCycleStart, mainMenuButtonCycleDuration, mainMenuButtonCycleDoAnimation, mainMenuButtonCycleAnimationOver, optionsImageOver)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		menuContainer:Visible(false)
		optionsMenuContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, musicSlider:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

creditsButton:EventFunction(function( self, e , ... )
	buttonOver(e, 4, mainMenuButtonCycleStart, mainMenuButtonCycleDuration, mainMenuButtonCycleDoAnimation, mainMenuButtonCycleAnimationOver, creditsImageOver)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		timeTrialContainer:Visible(false)
		versusContainer:Visible(false)
		optionsContainer:Visible(false)
		creditsContainer:Visible(false)
		exitContainer:Visible(false)
		creditsMenuContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, creditsBackToMenuButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)


exitButton:EventFunction(function( self, e , ... )
	buttonOver(e, 5, mainMenuButtonCycleStart, mainMenuButtonCycleDuration, mainMenuButtonCycleDoAnimation, mainMenuButtonCycleAnimationOver, exitImageOver)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		TriggerEvent(QUIT_GAME);
	end
end)

