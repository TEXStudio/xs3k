--this file uses components IDs from [10000 to 11000[ and tabindices from [900 to 1000[

local progressBarSize = 1.5
local markerSize = progressBarSize/15
local progressLabelHeight = 0.08

local progressBarContainer = CreateFrame("container", "progressBarContainer", 10000)
progressBarContainer:SetPosition(markerSize/2, 2.0-1.25*markerSize-progressLabelHeight)
progressBarContainer:SetSize(progressBarSize+markerSize, markerSize+progressLabelHeight)
progressBarContainer:Renderable(true)
progressBarContainer:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)

local progressLabel = CreateFrame("label", "progressLabel", 10200, 1)
progressLabel:SetText("Progress")
progressLabel:SetPosition(0.0, markerSize)
progressLabel:SetSize(0.65, progressLabelHeight)
progressLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
progressBarContainer:Attach(progressLabel)

local progressLabelLapText = CreateFrame("label", "progressLabelLapText", 10210, 1)
progressLabelLapText:SetText("Progress")
progressLabelLapText:SetPosition(select(1,progressLabel:GetSize()), markerSize)
progressLabelLapText:SetSize(0.65, progressLabelHeight)
progressLabelLapText:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
progressBarContainer:Attach(progressLabelLapText)

local progressBarImage = CreateFrame("image", "progressBarImage", 10100, 10100)
progressBarImage:SetPosition(0, 0)
progressBarImage:SetSize(progressBarSize, markerSize)
progressBarContainer:Attach(progressBarImage, 0)

local progressBarMarker = CreateFrame("image", "progressBarMarker", 10101, 10101)
progressBarMarker:SetSize(markerSize, markerSize)
progressBarMarker:SetPosition(progressBarSize*1-select(1, progressBarMarker:GetSize())/2, 0)
progressBarContainer:Attach(progressBarMarker, 0)


progressBarContainer:EventFunction(function( self, e , ... )
	if e == PLAYER_STATS then
		local p = select(10, ...)
		local laps = select(5,...)
		local maxlaps = select(13,...)
		if p ~= nil and p >= 0 and p <= 1 then
			progressBarMarker:SetPosition(progressBarSize*p-select(1, progressBarMarker:GetSize())/2, 0)
		end

		progressLabelLapText:SetText(laps.."/"..maxlaps)
	end
end)

gameStuffContainer:Attach(progressBarContainer)
