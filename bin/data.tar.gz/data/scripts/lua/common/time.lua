--this file uses components IDs from [11000 to 12000[ and tabindices from [1000 to 1100[

local timeTextSize = 0.06

local timeContainer = CreateFrame("container", "timeContainer", 11000)
timeContainer:SetSize(0.8, timeTextSize*2)
timeContainer:SetPosition(2.0-select(1, timeContainer:GetSize()), 2.0-select(2, timeContainer:GetSize()))
timeContainer:Renderable(true)
timeContainer:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)

local currentTimeContainer = CreateFrame("container", "currentTimeContainer", 11001)
currentTimeContainer:SetSize(select(1, timeContainer:GetSize()), select(2, timeContainer:GetSize())/2)
currentTimeContainer:SetPosition(0.0, select(2, timeContainer:GetSize())-timeTextSize)
timeContainer:Attach(currentTimeContainer)

local timeInfoLabel = CreateFrame("label", "timeInfoLabel", 11100, 1)
timeInfoLabel:SetText("Time")
timeInfoLabel:SetSize(5*timeTextSize, timeTextSize)
timeInfoLabel:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)
currentTimeContainer:Attach(timeInfoLabel)
local timeDataLabel = CreateFrame("label", "timeDataLabel", 11101, 1)
timeDataLabel:SetText("00:00.0")
timeDataLabel:SetBackgroundColour(0.0, 0.0, 1.0, 0.0)
timeDataLabel:SetSize(select(1, timeContainer:GetSize())-select(1, timeInfoLabel:GetSize()), timeTextSize)
timeDataLabel:SetPosition(select(1, timeInfoLabel:GetSize()), 0.0)
currentTimeContainer:Attach(timeDataLabel)


local bestTimeContainer = CreateFrame("container", "bestTimeContainer", 11002)
bestTimeContainer:SetSize(select(1, timeContainer:GetSize()), select(2, timeContainer:GetSize())/2)
bestTimeContainer:SetPosition(0.0, 0.0)
timeContainer:Attach(bestTimeContainer)

local bestTimeInfoLabel = CreateFrame("label", "bestTimeInfoLabel", 11102, 1)
bestTimeInfoLabel:SetText("Best")
bestTimeInfoLabel:SetSize(5*timeTextSize, timeTextSize)
bestTimeInfoLabel:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)
bestTimeContainer:Attach(bestTimeInfoLabel)
local bestTimeDataLabel = CreateFrame("label", "bestTimeDataLabel", 11103, 1)
bestTimeDataLabel:SetText("00:00.0")
bestTimeDataLabel:SetBackgroundColour(0.0, 0.0, 1.0, 0.0)
bestTimeDataLabel:SetSize(select(1, timeContainer:GetSize())-select(1, bestTimeInfoLabel:GetSize()), timeTextSize)
bestTimeDataLabel:SetPosition(select(1, bestTimeInfoLabel:GetSize()), 0.0)
bestTimeContainer:Attach(bestTimeDataLabel)


function formatMilliseconds(m)
	local n = m*1000
	local seconds, remainingMilliseconds = math.modf(n/1000)
	remainingMilliseconds = math.ceil(remainingMilliseconds*1000)
	local minutes,_ = math.modf(seconds/60.0)
	seconds = seconds % 60
	local c, __ = math.modf(remainingMilliseconds/100) --only display the hundreds of milliseconds
	if c >= 10 then c = 0 end
	return minutes, seconds, c
end

timeContainer:EventFunction(function( self, e , ... )
	if e == PLAYER_STATS then
		local currentTime = select(11, ...)
		if currentTime ~= nil then
			local minutes, seconds, remainingMilliseconds = formatMilliseconds(currentTime)
			local secondsPadding = ""
			if seconds < 10 then secondsPadding = "0" end
			timeDataLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
		end
		local bestTime = select(12, ...)
		if bestTime ~= nil then
			local minutes, seconds, remainingMilliseconds = formatMilliseconds(bestTime)
			local secondsPadding = ""
			if seconds < 10 then secondsPadding = "0" end
			bestTimeDataLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
		end
	end
end)

gameStuffContainer:Attach(timeContainer)
