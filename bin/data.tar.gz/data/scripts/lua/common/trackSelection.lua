--this file uses components IDs from [5000 to 6000[ and tabindices from [400 to 500[
--

local trackContainer = CreateFrame("container", "trackContainer", 5000)
trackContainer:SetPosition(0.1, 0.05)
trackContainer:SetSize(1.8, 1.4)
trackContainer:Renderable(true)
trackContainer:SetBackgroundColour(0.66, 0.66, 0.66, 0.35)
trackContainer:RenderBorder(true)
trackContainer:SetBorderColour(0.1, 0.1, 0.1, 0.5)
trackContainer:SetBorderThickness(0.02)

local trackSelectionContainerGlobalImage = CreateFrame("image", "trackSelectionContainerGlobalImage", 5208, 4208)
trackSelectionContainerGlobalImage:SetPosition(0.0, 0.0)
trackSelectionContainerGlobalImage:SetSize(trackContainer:GetSize())
trackContainer:Attach(trackSelectionContainerGlobalImage)



local currentTrackIndex = 1   --this is 1-based

local map_names = {}
local map_descriptions = {}
local map_texids = {}
local map_posx = {}
local map_posy = {}
local map_width = {}
local map_height = {}
local map_godmode = {}

for j = 0, TRACKS_COUNT-1 do
	map_names[(j+1)] = _G["TRACK"..j.."NAME"]
	map_descriptions[(j+1)] = _G["TRACK"..j.."DESCRIPTION"]
	map_texids[(j+1)] = _G["TRACK"..j.."TEXID"]
	map_posx[(j+1)] = _G["TRACK"..j.."TEXTPOSX"]
	map_posy[(j+1)] = _G["TRACK"..j.."TEXTPOSY"]
	map_width[(j+1)] = _G["TRACK"..j.."TEXTWIDTH"]
	map_height[(j+1)] = _G["TRACK"..j.."TEXTHEIGHT"]
	map_godmode[(j+1)] = _G["TRACK"..j.."GODMODE"]
end

--local map_names = {"SNOWY PEAKS", "ICE LAKE", "DESERT"}

local currentTrackName = CreateFrame("label", "currentTrackName", 5100, 1)
currentTrackName:SetText(map_names[currentTrackIndex])
currentTrackName:SetSize(1.6, 0.12)
currentTrackName:SetPosition(0.9-select(1, currentTrackName:GetSize())/2, 1.2)
currentTrackName:SetBackgroundColour(0.0, 0.0, 0.0, 1.0)
trackContainer:Attach(currentTrackName)


local trackSelectionPreviousTrackContainer = CreateFrame("container", "trackSelectionPreviousTrackContainer", 5001)
trackSelectionPreviousTrackContainer:SetPosition(0.1275, 0.45)
trackSelectionPreviousTrackContainer:SetSize(0.2, 0.6)
local trackSelectionPreviousTrackButton = CreateFrame("button", "trackSelectionPreviousTrackButton", 5300)
trackSelectionPreviousTrackButton:TabIndex(400)
trackSelectionPreviousTrackButton:SetPosition(0.0, 0.0)
trackSelectionPreviousTrackButton:SetSize(trackSelectionPreviousTrackContainer:GetSize())
trackSelectionPreviousTrackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
trackSelectionPreviousTrackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionPreviousTrackContainer:Attach(trackSelectionPreviousTrackButton)
local trackSelectionPreviousTrackImageUP = CreateFrame("image", "trackSelectionPreviousTrackImageUP", 5200, 5200)
trackSelectionPreviousTrackImageUP:SetPosition(0.0, 0.0)
trackSelectionPreviousTrackImageUP:SetSize(0.6, 0.6)
trackSelectionPreviousTrackContainer:Attach(trackSelectionPreviousTrackImageUP)
local trackSelectionPreviousTrackImageOVER = CreateFrame("image", "trackSelectionPreviousTrackImageOVER", 5201, 5201)
trackSelectionPreviousTrackImageOVER:SetPosition(0.0, 0.0)
trackSelectionPreviousTrackImageOVER:SetSize(0.6, 0.6)
trackSelectionPreviousTrackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionPreviousTrackContainer:Attach(trackSelectionPreviousTrackImageOVER)
trackContainer:Attach(trackSelectionPreviousTrackContainer)


local trackSelectionNextTrackContainer = CreateFrame("container", "trackSelectionNextTrackContainer", 5002)
--trackSelectionNextTrackContainer:SetPosition(1.5875, 0.45)
trackSelectionNextTrackContainer:SetPosition(1.48, 0.45)
trackSelectionNextTrackContainer:SetSize(0.2, 0.6)
local trackSelectionNextTrackButton = CreateFrame("button", "trackSelectionNextTrackButton", 5301)
trackSelectionNextTrackButton:TabIndex(401)
trackSelectionNextTrackButton:SetPosition(0.0, 0.0)
trackSelectionNextTrackButton:SetSize(trackSelectionNextTrackContainer:GetSize())
trackSelectionNextTrackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
trackSelectionNextTrackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionNextTrackContainer:Attach(trackSelectionNextTrackButton)
local trackSelectionNextTrackImageUP = CreateFrame("image", "trackSelectionNextTrackImageUP", 5202, 5202)
trackSelectionNextTrackImageUP:SetPosition(0.0, 0.0)
trackSelectionNextTrackImageUP:SetSize(0.6, 0.6)
trackSelectionNextTrackContainer:Attach(trackSelectionNextTrackImageUP)
local trackSelectionNextTrackImageOVER = CreateFrame("image", "trackSelectionNextTrackImageOVER", 5203, 5203)
trackSelectionNextTrackImageOVER:SetPosition(0.0, 0.0)
trackSelectionNextTrackImageOVER:SetSize(0.6, 0.6)
trackSelectionNextTrackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionNextTrackContainer:Attach(trackSelectionNextTrackImageOVER)
trackContainer:Attach(trackSelectionNextTrackContainer)


local trackSelectionBackContainer = CreateFrame("container", "trackSelectionBackContainer", 5003)
trackSelectionBackContainer:SetSize(0.3, 0.15)
--trackSelectionBackContainer:SetPosition(0.55, 0.05)
trackSelectionBackContainer:SetPosition((select(1, trackContainer:GetSize())-nextAndBackDistance)/2-select(1, trackSelectionBackContainer:GetSize()), 0.05)
local trackSelectionBackButton = CreateFrame("button", "trackSelectionBackButton", 5302)
trackSelectionBackButton:TabIndex(403)
trackSelectionBackButton:SetPosition(0.0, 0.0)
trackSelectionBackButton:SetSize(trackSelectionBackContainer:GetSize())
trackSelectionBackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
trackSelectionBackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionBackContainer:Attach(trackSelectionBackButton)
local trackSelectionBackImageUP = CreateFrame("image", "trackSelectionBackImageUP", 5204, 5204)
trackSelectionBackImageUP:SetPosition(0.0, 0.0)
trackSelectionBackImageUP:SetSize(trackSelectionBackContainer:GetSize())
trackSelectionBackContainer:Attach(trackSelectionBackImageUP)
local trackSelectionBackImageOVER = CreateFrame("image", "trackSelectionBackImageOVER", 5205, 5205)
trackSelectionBackImageOVER:SetPosition(0.0, 0.0)
trackSelectionBackImageOVER:SetSize(trackSelectionBackContainer:GetSize())
trackSelectionBackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionBackContainer:Attach(trackSelectionBackImageOVER)
trackContainer:Attach(trackSelectionBackContainer)


local trackSelectionNextContainer = CreateFrame("container", "trackSelectionNextContainer", 5004)
trackSelectionNextContainer:SetSize(0.3, 0.15)
--trackSelectionNextContainer:SetPosition(0.9, 0.05)
trackSelectionNextContainer:SetPosition((select(1, trackContainer:GetSize())+nextAndBackDistance)/2, 0.05)
local trackSelectionNextButton = CreateFrame("button", "trackSelectionNextButton", 5303)
trackSelectionNextButton:TabIndex(402)
trackSelectionNextButton:SetPosition(0.0, 0.0)
trackSelectionNextButton:SetSize(trackSelectionNextContainer:GetSize())
trackSelectionNextButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
trackSelectionNextButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionNextContainer:Attach(trackSelectionNextButton)
local trackSelectionNextImageUP = CreateFrame("image", "trackSelectionNextImageUP", 5206, 5206)
trackSelectionNextImageUP:SetPosition(0.0, 0.0)
trackSelectionNextImageUP:SetSize(trackSelectionNextContainer:GetSize())
trackSelectionNextContainer:Attach(trackSelectionNextImageUP)
local trackSelectionNextImageOVER = CreateFrame("image", "trackSelectionNextImageOVER", 5207, 5207)
trackSelectionNextImageOVER:SetPosition(0.0, 0.0)
trackSelectionNextImageOVER:SetSize(trackSelectionNextContainer:GetSize())
trackSelectionNextImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
trackSelectionNextContainer:Attach(trackSelectionNextImageOVER)
trackContainer:Attach(trackSelectionNextContainer)


local trackImageSize = 1.7

local trackImageContainer = CreateFrame("container", "trackImageContainer", 5005)
trackImageContainer:SetPosition(0.45, 0.25)
trackImageContainer:SetSize(trackImageSize*9.0/16.0, trackImageSize/2.0)
trackContainer:Attach(trackImageContainer)

for j = 1, TRACKS_COUNT do
	
	local trackImage = CreateFrame("image", "trackImage"..j , 5208+j, map_texids[j])
	trackImage:SetPosition(0.0, 0.0)
	trackImage:SetSize(trackImageContainer:GetSize())
	trackImageContainer:Attach(trackImage)	


	local tracktextbox = CreateFrame("textbox", "tracktextbox"..j, 5400+j, 1)
	tracktextbox:SetPosition(map_posx[j], map_posy[j])	
	tracktextbox:SetSize(map_width[j], map_height[j])
	tracktextbox:SetText(map_descriptions[j])
	tracktextbox:Multiline(true)
	tracktextbox:Wrapping(false)
	tracktextbox:SetLetterHeight(0.05)
	tracktextbox:SetBackgroundColour(0.0, 0.0, 0.0, 0.5)
	trackImageContainer:Attach(tracktextbox)

	trackImage:Visible(false)
	tracktextbox:Visible(false)

end

_G["trackImage"..currentTrackIndex]:Visible(true)
_G["tracktextbox"..currentTrackIndex]:Visible(false)



trackSelectionButtonCycleStart = { 0.0, 0.0, 0.0, 0.0 }
trackSelectionButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
trackSelectionButtonCycleDoAnimation = { false, false, false, false }
trackSelectionButtonCycleAnimationOver = { false, false, false, false }


trackSelectionBackButton:EventFunction(function(self, e, ...)
	--swapImages(e, trackSelectionBackImageUP, trackSelectionBackImageOVER)
	buttonOver(e, 1, trackSelectionButtonCycleStart, trackSelectionButtonCycleDuration, trackSelectionButtonCycleDoAnimation, trackSelectionButtonCycleAnimationOver, trackSelectionBackImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		trackContainer:Visible(false)
		if game_state["racetype"] == race_types[1] then
			menuContainer:Visible(true)
			TriggerEvent(COMPONENT_REQUEST_FOCUS, timeTrialButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
		else
			difficultySelectionContainer:Visible(true)
			if game_state["difficulty"] == difficulty_types[1] then
				TriggerEvent(COMPONENT_REQUEST_FOCUS, difficultySelectionEasyButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
			else
				TriggerEvent(COMPONENT_REQUEST_FOCUS, difficultySelectionHardButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
			end
		end
	end
end)

trackSelectionNextButton:EventFunction(function(self, e, ...)
	--swapImages(e, trackSelectionNextImageUP, trackSelectionNextImageOVER)
	buttonOver(e, 2, trackSelectionButtonCycleStart, trackSelectionButtonCycleDuration, trackSelectionButtonCycleDoAnimation, trackSelectionButtonCycleAnimationOver, trackSelectionNextImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		--game_state["course"] = map_types[currentTrackIndex]
		--print("wtf:", _G["TRACK"..(currentTrackIndex-1).."AUDIOID"])
		game_state["course"]["audioid"] = _G["TRACK"..(currentTrackIndex-1).."AUDIOID"]+UIMANAGER_FROM_LUA_BIAS
		game_state["course"]["groundid"] = _G["TRACK"..(currentTrackIndex-1).."GROUNDID"]+UIMANAGER_FROM_LUA_BIAS
		game_state["course"]["data"] = _G["TRACK"..(currentTrackIndex-1).."DATA"]
		game_state["course"]["scenerystart"] = _G["TRACK"..(currentTrackIndex-1).."SCENERYSTART"]+UIMANAGER_FROM_LUA_BIAS
		game_state["course"]["godmode"] = _G["TRACK"..(currentTrackIndex-1).."GODMODE"]+UIMANAGER_FROM_LUA_BIAS
		
		
		trackContainer:Visible(false)
		animalSelectionContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, dogSpeciesButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)


trackSelectionPreviousTrackButton:EventFunction(function(self, e, ...)
	--swapImages(e, trackSelectionPreviousTrackImageUP, trackSelectionPreviousTrackImageOVER)
	buttonOver(e, 3, trackSelectionButtonCycleStart, trackSelectionButtonCycleDuration, trackSelectionButtonCycleDoAnimation, trackSelectionButtonCycleAnimationOver, trackSelectionPreviousTrackImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		if currentTrackIndex <= 1 then
			--currentTrackIndex = 3
			currentTrackIndex = TRACKS_COUNT
		else
			currentTrackIndex = currentTrackIndex - 1
		end
		--for i = 1,3 do
		for i = 1,TRACKS_COUNT do
			_G["trackImage"..i]:Visible(false)
			_G["tracktextbox"..i]:Visible(false)
		end
		_G["trackImage"..currentTrackIndex]:Visible(true)
		_G["tracktextbox"..currentTrackIndex]:Visible(false)
		currentTrackName:SetText(map_names[currentTrackIndex])
	end
end)

trackSelectionNextTrackButton:EventFunction(function(self, e, ...)
	--swapImages(e, trackSelectionNextTrackImageUP, trackSelectionNextTrackImageOVER)
	buttonOver(e, 4, trackSelectionButtonCycleStart, trackSelectionButtonCycleDuration, trackSelectionButtonCycleDoAnimation, trackSelectionButtonCycleAnimationOver, trackSelectionNextTrackImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		--if currentTrackIndex >= 3 then
		if currentTrackIndex >= TRACKS_COUNT then
			currentTrackIndex = 1
		else
			currentTrackIndex = currentTrackIndex + 1
		end
		--for i = 1,3 do
		for i = 1,TRACKS_COUNT do
			_G["trackImage"..i]:Visible(false)
			_G["tracktextbox"..i]:Visible(false)
		end
		_G["trackImage"..currentTrackIndex]:Visible(true)
		_G["tracktextbox"..currentTrackIndex]:Visible(false)
		currentTrackName:SetText(map_names[currentTrackIndex])
	end
end)



trackContainer:Visible(false)
UIRoot:Attach(trackContainer)


