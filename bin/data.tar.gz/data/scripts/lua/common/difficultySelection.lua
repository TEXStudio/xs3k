--this file uses components IDs from [12000 to 13000[ and tabindices from [1100 to 1200[

local difficultySelectionContainer = CreateFrame("container", "difficultySelectionContainer", 12000)
difficultySelectionContainer:SetPosition(0.1, 0.05)
difficultySelectionContainer:SetSize(1.8, 1.4)
difficultySelectionContainer:Renderable(true)
difficultySelectionContainer:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)

local difficultySelectionContainerGlobalImage = CreateFrame("image", "difficultySelectionContainerGlobalImage", 12106, 4208)
difficultySelectionContainerGlobalImage:SetPosition(0.0, 0.0)
difficultySelectionContainerGlobalImage:SetSize(1.8, 1.4)
difficultySelectionContainer:Attach(difficultySelectionContainerGlobalImage)


local difficultySelectionLabel = CreateFrame("label", "difficultySelectionLabel", 12300, 1)
difficultySelectionLabel:SetText("Bots Difficulty")
difficultySelectionLabel:SetPosition(0.1, 1.2)
difficultySelectionLabel:SetSize(1.6, 0.1)
difficultySelectionContainer:Attach(difficultySelectionLabel)


local easyDifficultyContainer = CreateFrame("container", "easyDifficultyContainer", 12001)
easyDifficultyContainer:SetSize(0.3, 0.15)
easyDifficultyContainer:SetPosition((select(1, difficultySelectionContainer:GetSize())-select(1, easyDifficultyContainer:GetSize()))/2, 0.8)
local difficultySelectionEasyButton = CreateFrame("button", "difficultySelectionEasyButton", 12200)
difficultySelectionEasyButton:TabIndex(1100)
difficultySelectionEasyButton:SetPosition(0.0, 0.0)
difficultySelectionEasyButton:SetSize(easyDifficultyContainer:GetSize())
difficultySelectionEasyButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
difficultySelectionEasyButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
easyDifficultyContainer:Attach(difficultySelectionEasyButton)
local difficultySelectionEasyImageUP = CreateFrame("image", "difficultySelectionEasyImageUP", 12100, 12100)
difficultySelectionEasyImageUP:SetPosition(0.0, 0.0)
difficultySelectionEasyImageUP:SetSize(easyDifficultyContainer:GetSize())
easyDifficultyContainer:Attach(difficultySelectionEasyImageUP)
local difficultySelectionEasyImageOVER = CreateFrame("image", "difficultySelectionEasyImageOVER", 12101, 12101)
difficultySelectionEasyImageOVER:SetPosition(0.0, 0.0)
difficultySelectionEasyImageOVER:SetSize(easyDifficultyContainer:GetSize())
difficultySelectionEasyImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
easyDifficultyContainer:Attach(difficultySelectionEasyImageOVER)
difficultySelectionContainer:Attach(easyDifficultyContainer)

local hardDifficultyContainer = CreateFrame("container", "hardDifficultyContainer", 12002)
hardDifficultyContainer:SetSize(0.3, 0.15)
hardDifficultyContainer:SetPosition((select(1, difficultySelectionContainer:GetSize())-select(1, hardDifficultyContainer:GetSize()))/2, 0.5)
local difficultySelectionHardButton = CreateFrame("button", "difficultySelectionHardButton", 12201)
difficultySelectionHardButton:TabIndex(1101)
difficultySelectionHardButton:SetPosition(0.0, 0.0)
difficultySelectionHardButton:SetSize(hardDifficultyContainer:GetSize())
difficultySelectionHardButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
difficultySelectionHardButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
hardDifficultyContainer:Attach(difficultySelectionHardButton)
local difficultySelectionHardImageUP = CreateFrame("image", "difficultySelectionHardImageUP", 12102, 12102)
difficultySelectionHardImageUP:SetPosition(0.0, 0.0)
difficultySelectionHardImageUP:SetSize(hardDifficultyContainer:GetSize())
hardDifficultyContainer:Attach(difficultySelectionHardImageUP)
local difficultySelectionHardImageOVER = CreateFrame("image", "difficultySelectionHardImageOVER", 12103, 12103)
difficultySelectionHardImageOVER:SetPosition(0.0, 0.0)
difficultySelectionHardImageOVER:SetSize(hardDifficultyContainer:GetSize())
difficultySelectionHardImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
hardDifficultyContainer:Attach(difficultySelectionHardImageOVER)
difficultySelectionContainer:Attach(hardDifficultyContainer)




local difficultySelectionBackContainer = CreateFrame("container", "difficultySelectionBackContainer", 12003)
difficultySelectionBackContainer:SetSize(0.3, 0.15)
difficultySelectionBackContainer:SetPosition((select(1, difficultySelectionContainer:GetSize())-select(1, difficultySelectionBackContainer:GetSize()))/2, 0.05)
local difficultySelectionBackButton = CreateFrame("button", "difficultySelectionBackButton", 12202)
difficultySelectionBackButton:TabIndex(1102)
difficultySelectionBackButton:SetPosition(0.0, 0.0)
difficultySelectionBackButton:SetSize(difficultySelectionBackContainer:GetSize())
difficultySelectionBackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
difficultySelectionBackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
difficultySelectionBackContainer:Attach(difficultySelectionBackButton)
local difficultySelectionBackImageUP = CreateFrame("image", "difficultySelectionBackImageUP", 12104, 5204)
difficultySelectionBackImageUP:SetPosition(0.0, 0.0)
difficultySelectionBackImageUP:SetSize(difficultySelectionBackContainer:GetSize())
difficultySelectionBackContainer:Attach(difficultySelectionBackImageUP)
local difficultySelectionBackImageOVER = CreateFrame("image", "difficultySelectionBackImageOVER", 12105, 5205)
difficultySelectionBackImageOVER:SetPosition(0.0, 0.0)
difficultySelectionBackImageOVER:SetSize(difficultySelectionBackContainer:GetSize())
difficultySelectionBackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
difficultySelectionBackContainer:Attach(difficultySelectionBackImageOVER)
difficultySelectionContainer:Attach(difficultySelectionBackContainer)


difficultyButtonCycleStart = { 0.0, 0.0, 0.0 }
difficultyButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
difficultyButtonCycleDoAnimation = { false, false, false }
difficultyButtonCycleAnimationOver = { false, false, false }


difficultySelectionEasyButton:EventFunction(function(self, e, ...)
	--swapImages(e, difficultySelectionEasyImageUP, difficultySelectionEasyImageOVER)
	buttonOver(e, 1, difficultyButtonCycleStart, difficultyButtonCycleDuration, difficultyButtonCycleDoAnimation, difficultyButtonCycleAnimationOver, difficultySelectionEasyImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		game_state["difficulty"] = difficulty_types[1]
		difficultySelectionContainer:Visible(false)
		trackContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, trackSelectionPreviousTrackButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

difficultySelectionHardButton:EventFunction(function(self, e, ...)
	--swapImages(e, difficultySelectionHardImageUP, difficultySelectionHardImageOVER)
	buttonOver(e, 2, difficultyButtonCycleStart, difficultyButtonCycleDuration, difficultyButtonCycleDoAnimation, difficultyButtonCycleAnimationOver, difficultySelectionHardImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		game_state["difficulty"] = difficulty_types[2]
		difficultySelectionContainer:Visible(false)
		trackContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, trackSelectionPreviousTrackButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

difficultySelectionBackButton:EventFunction(function(self, e, ...)
	--swapImages(e, difficultySelectionBackImageUP, difficultySelectionBackImageOVER)
	buttonOver(e, 3, difficultyButtonCycleStart, difficultyButtonCycleDuration, difficultyButtonCycleDoAnimation, difficultyButtonCycleAnimationOver, difficultySelectionBackImageOVER)

	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		difficultySelectionContainer:Visible(false)
		menuContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, versusButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)


difficultySelectionContainer:Visible(false)
UIRoot:Attach(difficultySelectionContainer)
