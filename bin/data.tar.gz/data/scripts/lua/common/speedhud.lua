--this file uses components IDs from [15000 to 16000[ and tabindices from [1400 to 1500[
--caution: a lot of magic numbers are used; they mostly represent some ratio, so this is very related to the image we use to represent the hud
--this script was made such that the proportion of things are respected based on speedHudSize. so changing this variable will make things look the same, although scaled accordingly

local speedHudSize2 = 0.4
local speedHudSize = speedHudSize2*16/9.0


local speedHudContainer = CreateFrame("container", "speedHudContainer", 15000)
speedHudContainer:SetPosition(2.0-speedHudSize, 0.0)
speedHudContainer:SetSize(speedHudSize, speedHudSize2)
speedHudContainer:Renderable(true)
speedHudContainer:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)

local speedHudTreatImageSize = speedHudSize2*0.3 --speedHudSize2*0.765625
local speedHudTreatImageSize2 = speedHudSize*0.3
local speedHudTreatImageButtonX = 0.78*speedHudSize --0.787109375*speedHudSize
--local speedHudTreatImageButtonY = 1.5*speedHudSize2/4*speedHudSize2  --(2*speedHudSize2-0.5*speedHudSize2/5)/11+speedHudSize2/4 
--local speedHudTreatImageButtonY = 0.6*speedHudSize2/4 --(2*speedHudSize2-0.5*speedHudSize2/5)/11+speedHudSize2/4 
local speedHudTreatImageButtonY = 0.15*speedHudSize2

local speedHudImage = CreateFrame("image", "speedHudImage", 15100, 15100)
speedHudImage:SetPosition(0, 0)
speedHudImage:SetSize(speedHudSize, speedHudSize2)
local speedHudImage1 = CreateFrame("image", "speedHudImage1", 15101, 15101)
speedHudImage1:SetPosition(speedHudTreatImageButtonX, speedHudTreatImageButtonY)
speedHudImage1:SetSize(speedHudTreatImageSize, speedHudTreatImageSize2)
local speedHudImage2 = CreateFrame("image", "speedHudImage2", 15102, 15102)
speedHudImage2:SetPosition(speedHudTreatImageButtonX, speedHudTreatImageButtonY)
speedHudImage2:SetSize(speedHudTreatImageSize, speedHudTreatImageSize2)
local speedHudImage3 = CreateFrame("image", "speedHudImage3", 15103, 15103)
speedHudImage3:SetPosition(speedHudTreatImageButtonX, speedHudTreatImageButtonY)
speedHudImage3:SetSize(speedHudTreatImageSize, speedHudTreatImageSize2)
speedHudContainer:Attach(speedHudImage)
speedHudContainer:Attach(speedHudImage1)
speedHudContainer:Attach(speedHudImage2)
speedHudContainer:Attach(speedHudImage3)
speedHudImage:Visible(true)
speedHudImage1:Visible(true)
speedHudImage2:Visible(false)
speedHudImage3:Visible(false)


--max width: 0.725*speedHudSize
--max height: 0.53*speedHudSize2
local speedIndicatorImage = CreateFrame("image", "speedIndicatorImage", 15105, 15105)
speedIndicatorImage:SetPosition(0.025*speedHudSize/(0.4*16/9.0), 0.0575*speedHudSize2/0.4)
speedIndicatorImage:SetSize(0.725*speedHudSize, 0.53*speedHudSize2)
speedIndicatorImage:Visible(true)
speedHudContainer:Attach(speedIndicatorImage)

local speedIndicatorImageAlpha = CreateFrame("image", "speedIndicatorImageAlpha", 15104, 15104)
speedIndicatorImageAlpha:SetPosition(0.025*speedHudSize/(0.4*16/9.0), 0.0575*speedHudSize2/0.4)
speedIndicatorImageAlpha:SetSize(0.725*speedHudSize*0, 0.53*speedHudSize2)
speedIndicatorImageAlpha:Visible(true)
speedHudContainer:Attach(speedIndicatorImageAlpha)




local speedHudAnimationMinImageNum = 1
local speedHudAnimationMaxImageNum = 3

local speedHudWhipAnimationLast = 0
local speedHudAnimationStarted = false
local speedHudAnimationUpToDown = true
local speedHudAnimationStep = speedHudAnimationMinImageNum
local speedHudAnimationInterval = 100


speedHudContainer:EventFunction(function( self, e , ... )
	--listen for events here to update the size of the bars
	
	if speedHudAnimationStarted then
		local t = time("mlsec")
		if t >= speedHudWhipAnimationLast+speedHudAnimationInterval then
			_G["speedHudImage"..speedHudAnimationStep]:Visible(false)
			if speedHudAnimationUpToDown then
				speedHudAnimationStep = speedHudAnimationStep + 1
			else
				speedHudAnimationStep = speedHudAnimationStep - 1
			end
			_G["speedHudImage"..speedHudAnimationStep]:Visible(true)
			speedHudWhipAnimationLast = t
		end
		if speedHudAnimationStep >= speedHudAnimationMaxImageNum then
			speedHudAnimationUpToDown = false
		end
		if not speedHudAnimationUpToDown then
			if speedHudAnimationStep <= speedHudAnimationMinImageNum then
				speedHudAnimationStarted = false
			end
		end
	elseif e == PLAYER_STATS then
		local speed = select(9, ...)
		if speed ~= nil and speed >= 0 and speed <= 1.0 then 
			speedIndicatorImageAlpha:SetSize(0.725*speedHudSize*(1-speed), 0.53*speedHudSize2)
			speedIndicatorImageAlpha:SetPosition(0.025*speedHudSize/(0.4*16/9.0)+0.725*speedHudSize*speed, 0.0575*speedHudSize2/0.4)
		end
	elseif e == WHIP_HAPPENED then
		speedHudAnimationStarted = true
		speedHudAnimationStep = speedHudAnimationMinImageNum
		speedHudAnimationUpToDown = true
		speedHudTreatAnimationLast = time("mlsec")
	end
end)

gameStuffContainer:Attach(speedHudContainer)
