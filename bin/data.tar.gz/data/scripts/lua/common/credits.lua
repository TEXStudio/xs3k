--this file uses components IDs from [17000 to 18000[ and tabindices from [1600 to 1700[

local creditsMenuContainer = CreateFrame("container", "creditsMenuContainer", 17000)
creditsMenuContainer:SetPosition(0.1, 0.1)
creditsMenuContainer:SetSize(1.8, 1.3)
creditsMenuContainer:Renderable(true)
creditsMenuContainer:SetBackgroundColour(0.125, 0.125, 0.125, 0.85)

local creditsNameTextWidth = 0.67
local creditsNameTextHeight = 0.06

local _r,_g,_b,_a = 0.0, 0.0, 0.0, 0.0

local creditsDimitrisLabel = CreateFrame("label", "creditsDimitrisLabel", 17100, 1)
creditsDimitrisLabel:SetText("Dimitris")
creditsDimitrisLabel:SetSize(creditsNameTextWidth, creditsNameTextHeight)
creditsDimitrisLabel:SetPosition(0.6, 1.2)
creditsDimitrisLabel:SetBackgroundColour(_r, _g, _b, _a)
creditsMenuContainer:Attach(creditsDimitrisLabel, 1)

local creditsFrancisLabel = CreateFrame("label", "creditsFrancisLabel", 17101, 1)
creditsFrancisLabel:SetText("Francis KMz")
creditsFrancisLabel:SetSize(creditsNameTextWidth, creditsNameTextHeight)
creditsFrancisLabel:SetPosition(1.1, 0.9)
creditsFrancisLabel:SetBackgroundColour(_r, _g, _b, _a)
creditsMenuContainer:Attach(creditsFrancisLabel, 1)

local creditsFranciscoLabel = CreateFrame("label", "creditsFranciscoLabel", 17102, 1)
creditsFranciscoLabel:SetText("Francisco")
creditsFranciscoLabel:SetSize(creditsNameTextWidth, creditsNameTextHeight)
creditsFranciscoLabel:SetPosition(1.1, 0.6)
creditsFranciscoLabel:SetBackgroundColour(_r, _g, _b, _a)
creditsMenuContainer:Attach(creditsFranciscoLabel, 1)

local creditsMattLabel = CreateFrame("label", "creditsMattLabel", 17103, 1)
creditsMattLabel:SetText("Matt")
creditsMattLabel:SetSize(creditsNameTextWidth, creditsNameTextHeight)
creditsMattLabel:SetPosition(0.6, 0.3)
creditsMattLabel:SetBackgroundColour(_r, _g, _b, _a)
creditsMenuContainer:Attach(creditsMattLabel, 1)

local creditsNikLabel = CreateFrame("label", "creditsNikLabel", 17104, 1)
creditsNikLabel:SetText("Nikos")
creditsNikLabel:SetSize(creditsNameTextWidth, creditsNameTextHeight)
creditsNikLabel:SetPosition(0.1, 0.6)
creditsNikLabel:SetBackgroundColour(_r, _g, _b, _a)
creditsMenuContainer:Attach(creditsNikLabel, 1)

local creditsThomasLabel = CreateFrame("label", "creditsThomasLabel", 17105, 1)
creditsThomasLabel:SetText("Thomas")
creditsThomasLabel:SetSize(creditsNameTextWidth, creditsNameTextHeight)
creditsThomasLabel:SetPosition(0.1, 0.9)
creditsThomasLabel:SetBackgroundColour(_r, _g, _b, _a)
creditsMenuContainer:Attach(creditsThomasLabel, 1)


local creditsBackToMenuContainer = CreateFrame("container", "creditsBackToMenuContainer", 17001)
creditsBackToMenuContainer:SetSize(0.45, 0.225)
creditsBackToMenuContainer:SetPosition((select(1, creditsMenuContainer:GetSize())-select(1, creditsBackToMenuContainer:GetSize()))/2, (select(2, creditsMenuContainer:GetSize())-select(2, creditsBackToMenuContainer:GetSize()))/2)
local creditsBackToMenuImageUp = CreateFrame("image", "creditsBackToMenuImageUp", 17106, 13101)
creditsBackToMenuImageUp:SetPosition(0.0, 0.0)
creditsBackToMenuImageUp:SetSize(creditsBackToMenuContainer:GetSize())
local creditsBackToMenuImageOver = CreateFrame("image", "creditsBackToMenuImageOver", 17107, 13102)
creditsBackToMenuImageOver:SetPosition(0.0, 0.0)
creditsBackToMenuImageOver:SetSize(creditsBackToMenuContainer:GetSize())
creditsBackToMenuImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local creditsBackToMenuButton = CreateFrame("button", "creditsBackToMenuButton", 17200)
creditsBackToMenuButton:TabIndex(1600)
creditsBackToMenuButton:SetSize(creditsBackToMenuContainer:GetSize())
creditsBackToMenuButton:SetPosition(0.0, 0.0)
creditsBackToMenuButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
creditsBackToMenuButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
creditsBackToMenuContainer:Attach(creditsBackToMenuButton)
creditsBackToMenuContainer:Attach(creditsBackToMenuImageUp)
creditsBackToMenuContainer:Attach(creditsBackToMenuImageOver)
creditsMenuContainer:Attach(creditsBackToMenuContainer)


local pi = 3.14159265
local creditsCurrentTime = 0

creditsMenuContainer:EventFunction(function(self, e, ...)
	if e == UPDATE then
		local delta = select(1, ...)*0.3
		local t = creditsCurrentTime + delta

		local dimY = 0.45*math.sin(pi/2-t)+0.75
		local dimX = 0.5*math.cos(pi/2-t)+0.6
		creditsDimitrisLabel:SetPosition(dimX, dimY)

		local franY = 0.45*math.sin(pi/6-t)+0.75
		local franX = 0.5*math.cos(pi/6-t)+0.6
		creditsFrancisLabel:SetPosition(franX, franY)

		local fran2Y = 0.45*math.sin(11*pi/6-t)+0.75
		local fran2X = 0.5*math.cos(11*pi/6-t)+0.6
		creditsFranciscoLabel:SetPosition(fran2X, fran2Y)

		local mattY = 0.45*math.sin(3*pi/2-t)+0.75
		local mattX = 0.5*math.cos(3*pi/2-t)+0.6
		creditsMattLabel:SetPosition(mattX, mattY)

		local nikY = 0.45*math.sin(7*pi/6-t)+0.75
		local nikX = 0.5*math.cos(7*pi/6-t)+0.6
		creditsNikLabel:SetPosition(nikX, nikY)

		local TY = 0.45*math.sin(5*pi/6-t)+0.75
		local TX = 0.5*math.cos(5*pi/6-t)+0.6
		creditsThomasLabel:SetPosition(TX, TY)

		creditsCurrentTime = t
	end
end)

creditsMenuButtonCycleStart = { 0.0 }
creditsMenuButtonCycleDuration = { buttonAnimationCycleDuration }
creditsMenuButtonCycleDoAnimation = { false }
creditsMenuButtonCycleAnimationOver = { false }


creditsBackToMenuButton:EventFunction(function(self, e, ...)
	buttonOver(e, 1, creditsMenuButtonCycleStart, creditsMenuButtonCycleDuration, creditsMenuButtonCycleDoAnimation, scoreMenuButtonCycleAnimationOver, creditsBackToMenuImageOver)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		
		timeTrialContainer:Visible(true)
		versusContainer:Visible(true)
		optionsContainer:Visible(true)
		creditsContainer:Visible(true)
		exitContainer:Visible(true)
		creditsMenuContainer:Visible(false)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, creditsButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)


creditsMenuContainer:Visible(false)
UIRoot:Attach(creditsMenuContainer)