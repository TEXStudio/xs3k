--this file uses components IDs from [2000 to 3000[ and tabindices from [100 to 200[
--caution: a lot of magic numbers are used; they mostly represent some ratio, so this is very related to the image we use to represent the hud
--this script was made such that the proportion of things are respected based on hudSize. so changing this variable will make things look the same, although scaled accordingly

local hudSize = 0.5


local hudContainer = CreateFrame("container", "hudContainer", 2000)
hudContainer:SetPosition(0.0, -0.025)
hudContainer:SetSize(hudSize, hudSize)
hudContainer:Renderable(true)
hudContainer:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)

--numberTreatsLabel:SetSize(hudSize/5, hudSize/5)
--numberTreatsLabel:SetPosition(0.44*hudSize-select(1, numberTreatsLabel:GetSize())/2, (2*hudSize-0.5*select(2, numberTreatsLabel:GetSize()))/12)
local hudTreatImageButtonX = 0.335*hudSize
local hudTreatImageButtonY = (2*hudSize-0.5*hudSize/5)/11+hudSize/4
local hudTreatImageSize = hudSize/8
local hudTreatImageSize2 = hudSize/8*16/9.0

local hudImage = CreateFrame("image", "hudImage", 2200, 2200)
hudImage:SetPosition(0, 0)
hudImage:SetSize(hudSize, hudSize)
local hudImage1 = CreateFrame("image", "hudImage1", 2201, 2202)
hudImage1:SetPosition(hudTreatImageButtonX, hudTreatImageButtonY)
hudImage1:SetSize(hudTreatImageSize, hudTreatImageSize2)
local hudImage2 = CreateFrame("image", "hudImage2", 2202, 2203)
hudImage2:SetPosition(hudTreatImageButtonX, hudTreatImageButtonY)
hudImage2:SetSize(hudTreatImageSize, hudTreatImageSize2)
local hudImage3 = CreateFrame("image", "hudImage3", 2203, 2204)
hudImage3:SetPosition(hudTreatImageButtonX, hudTreatImageButtonY)
hudImage3:SetSize(hudTreatImageSize, hudTreatImageSize2)
local hudImage4 = CreateFrame("image", "hudImage4", 2204, 2205)
hudImage4:SetPosition(hudTreatImageButtonX, hudTreatImageButtonY)
hudImage4:SetSize(hudTreatImageSize, hudTreatImageSize2)
hudContainer:Attach(hudImage, 0)
hudContainer:Attach(hudImage1, 0)
hudContainer:Attach(hudImage2, 0)
hudContainer:Attach(hudImage3, 0)
hudContainer:Attach(hudImage4, 0)

hudImage:Visible(true)
hudImage1:Visible(true)
hudImage2:Visible(false)
hudImage3:Visible(false)
hudImage4:Visible(false)




local rankLabel = CreateFrame("label", "rankLabel", 2100, 1)
rankLabel:SetText("2")
rankLabel:SetSize(hudSize/3, hudSize/3)
rankLabel:SetPosition((hudSize-0.5*select(1, rankLabel:GetSize()))/10, 0.32*hudSize - 0.5*select(2, rankLabel:GetSize()))
rankLabel:SetBackgroundColour(0.0, 0.0, 1.0, 0.0)
rankLabel:SetBorderColour(0, 0, 0, 0)
hudContainer:Attach(rankLabel)

local numberTreatsLabel = CreateFrame("label", "numberTreatsLabel", 2107, 1)
numberTreatsLabel:SetText("5")
numberTreatsLabel:SetSize(hudSize/5, hudSize/5)
numberTreatsLabel:SetPosition(0.44*hudSize-select(1, numberTreatsLabel:GetSize())/2, (2*hudSize-0.5*select(2, numberTreatsLabel:GetSize()))/12)
numberTreatsLabel:SetBackgroundColour(0.0, 0.0, 1.0, 0.0)
numberTreatsLabel:SetBorderColour(0, 0, 0, 0)
hudContainer:Attach(numberTreatsLabel)

--the space for all bars is 0.39% of the whole width
local barStartX = hudSize*0.55
local spaceBetweenBars = hudSize*0.03
local barWidth = hudSize*0.11-spaceBetweenBars
local maxBarHeight = hudSize*0.4

local eLabel = CreateFrame("label", "eLabel", 2102, 1)
eLabel:SetText("E")
eLabel:SetSize(hudSize/8, hudSize/8)
eLabel:SetPosition(barStartX, (2*hudSize-0.5*select(2, eLabel:GetSize()))/12)
eLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
eLabel:SetBorderColour(0, 0, 0, 0)
local eBar = CreateFrame("label", "eBar", 2101, 1)
eBar:SetPosition(barStartX, (2*hudSize-0.5*select(2, eLabel:GetSize()))/12+select(2, eLabel:GetSize()))
eBar:SetSize(barWidth, maxBarHeight*0.5)
eBar:SetBackgroundColour(0.0, 1.0, 0.0, 1.0)
eBar:SetBorderColour(0, 0, 0, 0)
hudContainer:Attach(eBar)
hudContainer:Attach(eLabel)

local dLabel = CreateFrame("label", "dLabel", 2104, 1)
dLabel:SetText("D")
dLabel:SetPosition(barStartX+barWidth+spaceBetweenBars, (2*hudSize-0.5*select(2, eLabel:GetSize()))/12)
dLabel:SetSize(hudSize/8, hudSize/8)
dLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
dLabel:SetBorderColour(0, 0, 0, 0)
local dBar = CreateFrame("label", "dBar", 2103, 1)
dBar:SetPosition(barStartX+barWidth+spaceBetweenBars, (2*hudSize-0.5*select(2, dLabel:GetSize()))/12+select(2, dLabel:GetSize()))
dBar:SetSize(barWidth, maxBarHeight*1.0)
dBar:SetBackgroundColour(0.0, 0.0, 1.0, 1.0)
dBar:SetBorderColour(0, 0, 0, 0)
hudContainer:Attach(dBar)
hudContainer:Attach(dLabel)

local mLabel = CreateFrame("label", "mLabel", 2106, 1)
mLabel:SetText("M")
mLabel:SetPosition(barStartX+2*(barWidth+spaceBetweenBars), (2*hudSize-0.5*select(2, eLabel:GetSize()))/12)
mLabel:SetSize(hudSize/8, hudSize/8)
mLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
mLabel:SetBorderColour(0, 0, 0, 0)
local mBar = CreateFrame("label", "mBar", 2105, 1)
mBar:SetPosition(barStartX+2*(barWidth+spaceBetweenBars), (2*hudSize-0.5*select(2, dLabel:GetSize()))/12+select(2, dLabel:GetSize()))
mBar:SetSize(barWidth, maxBarHeight*0.8)
mBar:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
mBar:SetBorderColour(0, 0, 0, 0)
hudContainer:Attach(mBar)
hudContainer:Attach(mLabel)


local hudAnimationMinImageNum = 1
local hudAnimationMaxImageNum = 4

local hudTreatAnimationLast = 0
local hudAnimationStarted = false
local hudAnimationUpToDown = true
local hudAnimationStep = hudAnimationMinImageNum
local hudAnimationInterval = 100



hudContainer:EventFunction(function( self, e , ... )
	--listen for events here to update the size of the bars
	if hudAnimationStarted then
		local t = time("mlsec")
		if t >= hudTreatAnimationLast+hudAnimationInterval then
			_G["hudImage"..hudAnimationStep]:Visible(false)
			if hudAnimationUpToDown then
				hudAnimationStep = hudAnimationStep + 1
			else
				hudAnimationStep = hudAnimationStep - 1
			end
			_G["hudImage"..hudAnimationStep]:Visible(true)
			hudTreatAnimationLast = t
		end
		if hudAnimationStep >= hudAnimationMaxImageNum then
			hudAnimationUpToDown = false
		end
		if not hudAnimationUpToDown then
			if hudAnimationStep <= hudAnimationMinImageNum then
				hudAnimationStarted = false
			end
		end
	elseif e == PLAYER_STATS then
		local treats = select(4, ...)
		local eV = select(6, ...)
		local dV = select(7, ...)
		local mV = select(8, ...)

		if treats ~= nil then 
			if treats >= 9 then
				numberTreatsLabel:SetText("9") 
			else
				numberTreatsLabel:SetText(treats) 
			end
		end

		if eV ~= nil and eV >= 0 and eV <= 1 then eBar:SetSize(barWidth, maxBarHeight*eV) end
		if dV ~= nil and dV >= 0 and dV <= 1 then dBar:SetSize(barWidth, maxBarHeight*dV) end
		if mV ~= nil and mV >= 0 and mV <= 1 then mBar:SetSize(barWidth, maxBarHeight*mV) end
	
	elseif e == PLAYER_POSITION then 

		local position = tonumber(select(3,...))

		if position > 0 then 
			rankLabel:SetText(tostring(position))
		end

	elseif e == TREAT_HAPPENED and tonumber(numberTreatsLabel:GetText()) > 0 then
		hudAnimationStarted = true
		hudAnimationStep = hudAnimationMinImageNum
		hudAnimationUpToDown = true
		hudTreatAnimationLast = time("mlsec")
	end
end)

gameStuffContainer:Attach(hudContainer)
