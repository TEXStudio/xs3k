--this file uses components IDs from [3000 to 4000[ and tabindices from [200 to 300[

local animalSelectionContainerWidth = 1.8
local animalSelectionContainerHeight = 1.4
local animalBorderThickness = 0.02

local animalSelectionContainer = CreateFrame("container", "animalSelectionContainer", 3000)
animalSelectionContainer:SetPosition(0.1, 0.05)
animalSelectionContainer:SetSize(animalSelectionContainerWidth, animalSelectionContainerHeight)
animalSelectionContainer:Renderable(true)
animalSelectionContainer:SetBackgroundColour(0.66, 0.66, 0.66, 0.35)
animalSelectionContainer:SetBorderColour(0.1, 0.1, 0.1, 0.5)
animalSelectionContainer:RenderBorder(true)
animalSelectionContainer:SetBorderThickness(animalBorderThickness)

local animalSelectionContainerGlobalImage = CreateFrame("image", "animalSelectionContainerGlobalImage", 3229, 4208)
animalSelectionContainerGlobalImage:SetPosition(0.0, 0.0)
animalSelectionContainerGlobalImage:SetSize(animalSelectionContainerWidth, animalSelectionContainerHeight)
animalSelectionContainer:Attach(animalSelectionContainerGlobalImage)


local selectYourAnimalLabel = CreateFrame("label", "selectYourAnimalLabel", 3104, 1)
selectYourAnimalLabel:SetText("Select Your 4 Animals")
selectYourAnimalLabel:SetPosition(0.1, 1.25)
selectYourAnimalLabel:SetSize(1.6, 0.065)
selectYourAnimalLabel:SetBorderColour(0, 0, 0, 0)
selectYourAnimalLabel:SetBackgroundColour(0, 0, 0, 1)
animalSelectionContainer:Attach(selectYourAnimalLabel)

animalsInPackText = "Pets In Pack:"

local animalsInPackLabel = CreateFrame("label", "animalsInPackLabel", 3119, 1)
animalsInPackLabel:SetText(animalsInPackText.."0")
animalsInPackLabel:SetPosition(0.1, 1.1)
animalsInPackLabel:SetSize(0.725, 0.05)
animalsInPackLabel:SetBorderColour(0, 0, 0, 0)
animalsInPackLabel:SetBackgroundColour(0.0, 0.0, 0.0, 1.0)
animalSelectionContainer:Attach(animalsInPackLabel)



local speciesImageHeight = 0.2
local speciesImageWidth = 0.4
local speciesBracketWidth = 0.0125
local speciesBracketLength = 0.05

local speciesBracketContainer = CreateFrame("container", "speciesBracketContainer", 3001)
speciesBracketContainer:SetPosition(0.2, 0.5)
speciesBracketContainer:SetSize(speciesImageWidth+2*speciesBracketLength, speciesImageHeight)

local speciesLeftBracketBody = CreateFrame("label", "speciesLeftBracketBody", 3107, 1)
speciesLeftBracketBody:SetPosition(0.0, speciesBracketWidth)
speciesLeftBracketBody:SetSize(speciesBracketWidth, speciesImageHeight-2*speciesBracketWidth)
speciesLeftBracketBody:SetBorderColour(0, 0, 0, 0)
speciesLeftBracketBody:SetBackgroundColour(0, 0, 0, 1)
speciesBracketContainer:Attach(speciesLeftBracketBody)
local speciesLeftBracketTop = CreateFrame("label", "speciesLeftBracketTop", 3108, 1)
speciesLeftBracketTop:SetPosition(0.0, speciesImageHeight-speciesBracketWidth)
speciesLeftBracketTop:SetSize(speciesBracketLength, speciesBracketWidth)
speciesLeftBracketTop:SetBorderColour(0, 0, 0, 0)
speciesLeftBracketTop:SetBackgroundColour(speciesLeftBracketBody:GetBackgroundColour())
speciesBracketContainer:Attach(speciesLeftBracketTop)
local speciesLeftBracketBottom = CreateFrame("label", "speciesLeftBracketBottom", 3109, 1)
speciesLeftBracketBottom:SetPosition(0.0, 0.0)
speciesLeftBracketBottom:SetSize(speciesBracketLength, speciesBracketWidth)
speciesLeftBracketBottom:SetBorderColour(0, 0, 0, 0)
speciesLeftBracketBottom:SetBackgroundColour(speciesLeftBracketBody:GetBackgroundColour())
speciesBracketContainer:Attach(speciesLeftBracketBottom)

local speciesRightBracketBody = CreateFrame("label", "speciesRightBracketBody", 3110, 1)
speciesRightBracketBody:SetPosition(speciesImageWidth+2*speciesBracketLength-speciesBracketWidth, speciesBracketWidth)
speciesRightBracketBody:SetSize(speciesBracketWidth, speciesImageHeight-2*speciesBracketWidth)
speciesRightBracketBody:SetBorderColour(0, 0, 0, 0)
speciesRightBracketBody:SetBackgroundColour(speciesLeftBracketBody:GetBackgroundColour())
speciesBracketContainer:Attach(speciesRightBracketBody)
local speciesRightBracketTop = CreateFrame("label", "speciesRightBracketTop", 3111, 1)
speciesRightBracketTop:SetPosition(speciesImageWidth+speciesBracketLength, speciesImageHeight-speciesBracketWidth)
speciesRightBracketTop:SetSize(speciesBracketLength, speciesBracketWidth)
speciesRightBracketTop:SetBorderColour(0, 0, 0, 0)
speciesRightBracketTop:SetBackgroundColour(speciesLeftBracketBody:GetBackgroundColour())
speciesBracketContainer:Attach(speciesRightBracketTop)
local speciesRightBracketBottom = CreateFrame("label", "speciesRightBracketBottom", 3112, 1)
speciesRightBracketBottom:SetPosition(speciesImageWidth+speciesBracketLength, 0.0)
speciesRightBracketBottom:SetSize(speciesBracketLength, speciesBracketWidth)
speciesRightBracketBottom:SetBorderColour(0, 0, 0, 0)
speciesRightBracketBottom:SetBackgroundColour(speciesLeftBracketBody:GetBackgroundColour())
speciesBracketContainer:Attach(speciesRightBracketBottom)
animalSelectionContainer:Attach(speciesBracketContainer)

local firstSpeciesPosY = animalSelectionContainerHeight-animalBorderThickness-0.2-0.2-0.15
local speciesPosX = 0.2



local animalSelectionImage = CreateFrame("image", "animalSelectionImage", 3228, 4206)
animalSelectionImage:SetPosition(speciesPosX-speciesBracketLength-speciesBracketWidth, firstSpeciesPosY-2*(speciesImageHeight+3*speciesBracketWidth))
animalSelectionImage:SetSize(speciesImageWidth+2*(speciesBracketLength+speciesBracketWidth), 3*(speciesImageHeight+3*speciesBracketWidth))
animalSelectionImage:SetBackgroundColour(0.0, 0.0, 0.0, 0.5)
animalSelectionContainer:Attach(animalSelectionImage)



local dogSpeciesContainer = CreateFrame("container", "dogSpeciesContainer", 3012)
dogSpeciesContainer:SetPosition(speciesPosX, firstSpeciesPosY)
dogSpeciesContainer:SetSize(speciesImageWidth, speciesImageHeight)
animalSelectionContainer:Attach(dogSpeciesContainer)
local dogSpeciesButton = CreateFrame("button", "dogSpeciesButton", 3302) 
dogSpeciesButton:SetPosition(0, 0)
dogSpeciesButton:SetSize(dogSpeciesContainer:GetSize())
dogSpeciesButton:TabIndex(200)
dogSpeciesButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
dogSpeciesButton:SetBorderColour(0, 0, 0, 0)
dogSpeciesContainer:Attach(dogSpeciesButton)
local dogSpeciesImageUP = CreateFrame("image", "dogSpeciesImageUP", 3200, 3200)
dogSpeciesImageUP:SetPosition(0, 0)
dogSpeciesImageUP:SetSize(dogSpeciesContainer:GetSize())
dogSpeciesContainer:Attach(dogSpeciesImageUP)
local dogSpeciesImageOVER = CreateFrame("image", "dogSpeciesImageOVER", 3201, 3201)
dogSpeciesImageOVER:SetPosition(0, 0)
dogSpeciesImageOVER:SetSize(dogSpeciesContainer:GetSize())
dogSpeciesImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
dogSpeciesContainer:Attach(dogSpeciesImageOVER)
local dogSpeciesImageDOWN = CreateFrame("image", "dogSpeciesImageDOWN", 3202, 3202)
dogSpeciesImageDOWN:SetPosition(0, 0)
dogSpeciesImageDOWN:SetSize(dogSpeciesContainer:GetSize())
dogSpeciesContainer:Attach(dogSpeciesImageDOWN)
dogSpeciesImageUP:Visible(false)
dogSpeciesImageOVER:Visible(false)
dogSpeciesImageDOWN:Visible(true)

local mouseSpeciesContainer = CreateFrame("container", "mouseSpeciesContainer", 3013)
mouseSpeciesContainer:SetPosition(speciesPosX, firstSpeciesPosY-(speciesImageHeight+2*speciesBracketWidth))
mouseSpeciesContainer:SetSize(speciesImageWidth, speciesImageHeight)
animalSelectionContainer:Attach(mouseSpeciesContainer)
local mouseSpeciesButton = CreateFrame("button", "mouseSpeciesButton", 3303) 
mouseSpeciesButton:SetPosition(0, 0)
mouseSpeciesButton:SetSize(mouseSpeciesContainer:GetSize())
mouseSpeciesButton:TabIndex(201)
mouseSpeciesButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
mouseSpeciesButton:SetBorderColour(0, 0, 0, 0)
mouseSpeciesContainer:Attach(mouseSpeciesButton)
local mouseSpeciesImageUP = CreateFrame("image", "mouseSpeciesImageUP", 3203, 3203)
mouseSpeciesImageUP:SetPosition(0, 0)
mouseSpeciesImageUP:SetSize(mouseSpeciesContainer:GetSize())
mouseSpeciesContainer:Attach(mouseSpeciesImageUP)
local mouseSpeciesImageOVER = CreateFrame("image", "mouseSpeciesImageOVER", 3204, 3204)
mouseSpeciesImageOVER:SetPosition(0, 0)
mouseSpeciesImageOVER:SetSize(mouseSpeciesContainer:GetSize())
mouseSpeciesImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
mouseSpeciesContainer:Attach(mouseSpeciesImageOVER)
local mouseSpeciesImageDOWN = CreateFrame("image", "mouseSpeciesImageDOWN", 3205, 3205)
mouseSpeciesImageDOWN:SetPosition(0, 0)
mouseSpeciesImageDOWN:SetSize(mouseSpeciesContainer:GetSize())
mouseSpeciesContainer:Attach(mouseSpeciesImageDOWN)
mouseSpeciesImageUP:Visible(true)
mouseSpeciesImageOVER:Visible(false)
mouseSpeciesImageDOWN:Visible(false)

local dinoSpeciesContainer = CreateFrame("container", "dinoSpeciesContainer", 3014)
dinoSpeciesContainer:SetPosition(speciesPosX, firstSpeciesPosY-2*(speciesImageHeight+2*speciesBracketWidth))
dinoSpeciesContainer:SetSize(speciesImageWidth, speciesImageHeight)
animalSelectionContainer:Attach(dinoSpeciesContainer)
local dinoSpeciesButton = CreateFrame("button", "dinoSpeciesButton", 3304) 
dinoSpeciesButton:SetPosition(0, 0)
dinoSpeciesButton:SetSize(dinoSpeciesContainer:GetSize())
dinoSpeciesButton:TabIndex(202)
dinoSpeciesButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
dinoSpeciesButton:SetBorderColour(0, 0, 0, 0)
dinoSpeciesContainer:Attach(dinoSpeciesButton)
local dinoSpeciesImageUP = CreateFrame("image", "dinoSpeciesImageUP", 3206, 3206)
dinoSpeciesImageUP:SetPosition(0, 0)
dinoSpeciesImageUP:SetSize(dinoSpeciesContainer:GetSize())
dinoSpeciesContainer:Attach(dinoSpeciesImageUP)
local dinoSpeciesImageOVER = CreateFrame("image", "dinoSpeciesImageOVER", 3207, 3207)
dinoSpeciesImageOVER:SetPosition(0, 0)
dinoSpeciesImageOVER:SetSize(dinoSpeciesContainer:GetSize())
dinoSpeciesImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
dinoSpeciesContainer:Attach(dinoSpeciesImageOVER)
local dinoSpeciesImageDOWN = CreateFrame("image", "dinoSpeciesImageDOWN", 3208, 3208)
dinoSpeciesImageDOWN:SetPosition(0, 0)
dinoSpeciesImageDOWN:SetSize(dinoSpeciesContainer:GetSize())
dinoSpeciesContainer:Attach(dinoSpeciesImageDOWN)
dinoSpeciesImageUP:Visible(true)
dinoSpeciesImageOVER:Visible(false)
dinoSpeciesImageDOWN:Visible(false)




local individualsImageHeight = speciesImageHeight
local individualsImageWidth = 0.9
local individualsBracketWidth = speciesBracketWidth
local individualsBracketLength = speciesBracketLength

local individualsBracketContainer = CreateFrame("container", "individualsBracketContainer", 3002)
individualsBracketContainer:SetPosition(0.2, 0.5)
individualsBracketContainer:SetSize(individualsImageWidth+2*individualsBracketLength, individualsImageHeight)

local individualsLeftBracketBody = CreateFrame("label", "individualsLeftBracketBody", 3113, 1)
individualsLeftBracketBody:SetPosition(0.02, individualsBracketWidth)
individualsLeftBracketBody:SetSize(individualsBracketWidth, individualsImageHeight-2*individualsBracketWidth)
individualsLeftBracketBody:SetBorderColour(0, 0, 0, 0)
individualsLeftBracketBody:SetBackgroundColour(0, 0, 0, 1)
individualsBracketContainer:Attach(individualsLeftBracketBody)
local individualsLeftBracketTop = CreateFrame("label", "individualsLeftBracketTop", 3114, 1)
individualsLeftBracketTop:SetPosition(0.02, individualsImageHeight-individualsBracketWidth)
individualsLeftBracketTop:SetSize(individualsBracketLength, individualsBracketWidth)
individualsLeftBracketTop:SetBorderColour(0, 0, 0, 0)
individualsLeftBracketTop:SetBackgroundColour(individualsLeftBracketBody:GetBackgroundColour())
individualsBracketContainer:Attach(individualsLeftBracketTop)
local individualsLeftBracketBottom = CreateFrame("label", "individualsLeftBracketBottom", 3115, 1)
individualsLeftBracketBottom:SetPosition(0.02, 0.0)
individualsLeftBracketBottom:SetSize(individualsBracketLength, individualsBracketWidth)
individualsLeftBracketBottom:SetBorderColour(0, 0, 0, 0)
individualsLeftBracketBottom:SetBackgroundColour(individualsLeftBracketBody:GetBackgroundColour())
individualsBracketContainer:Attach(individualsLeftBracketBottom)

local individualsRightBracketBody = CreateFrame("label", "individualsRightBracketBody", 3116, 1)
individualsRightBracketBody:SetPosition(individualsImageWidth+2*individualsBracketLength-individualsBracketWidth-0.02, individualsBracketWidth)
individualsRightBracketBody:SetSize(individualsBracketWidth, individualsImageHeight-2*individualsBracketWidth)
individualsRightBracketBody:SetBorderColour(0, 0, 0, 0)
individualsRightBracketBody:SetBackgroundColour(individualsLeftBracketBody:GetBackgroundColour())
individualsBracketContainer:Attach(individualsRightBracketBody)
local individualsRightBracketTop = CreateFrame("label", "individualsRightBracketTop", 3117, 1)
individualsRightBracketTop:SetPosition(individualsImageWidth+individualsBracketLength-0.02, individualsImageHeight-individualsBracketWidth)
individualsRightBracketTop:SetSize(individualsBracketLength, individualsBracketWidth)
individualsRightBracketTop:SetBorderColour(0, 0, 0, 0)
individualsRightBracketTop:SetBackgroundColour(individualsLeftBracketBody:GetBackgroundColour())
individualsBracketContainer:Attach(individualsRightBracketTop)
local individualsRightBracketBottom = CreateFrame("label", "individualsRightBracketBottom", 3118, 1)
individualsRightBracketBottom:SetPosition(individualsImageWidth+individualsBracketLength-0.02, 0.0)
individualsRightBracketBottom:SetSize(individualsBracketLength, individualsBracketWidth)
individualsRightBracketBottom:SetBorderColour(0, 0, 0, 0)
individualsRightBracketBottom:SetBackgroundColour(individualsLeftBracketBody:GetBackgroundColour())
individualsBracketContainer:Attach(individualsRightBracketBottom)


local firstIndividualsPosY = firstSpeciesPosY
--local individualsPosX = 0.85
local individualsPosX = 0.75
local individualsContainerHeight = 3*(speciesImageHeight+2*speciesBracketWidth)
local individualsPaddingY = 0.025
local individualsBarsPaddingY = 0.02
local individualsBarMaxHeight = individualsImageHeight/5
local individualsBarMaxWidth = individualsImageWidth/3
local individualsBarContainerHeight = 3*(individualsBarMaxHeight+individualsBarsPaddingY)-individualsBarsPaddingY

local individualsContainer = CreateFrame("container", "individualsContainer", 3003)
--individualsContainer:SetPosition(individualsPosX, firstIndividualsPosY-2*(speciesImageHeight+2*speciesBracketWidth))
individualsContainer:SetPosition(individualsPosX, firstIndividualsPosY-2*(speciesImageHeight+2*speciesBracketWidth)-0.02)
--individualsContainer:Renderable(true)
--individualsContainer:SetBackgroundColour(1.0, 1.0, 0.0, 1.0)
--individualsContainer:SetSize(individualsImageWidth+2*individualsBracketLength, individualsContainerHeight)
individualsContainer:SetSize(individualsImageWidth+2*individualsBracketLength, individualsContainerHeight+0.04)
animalSelectionContainer:Attach(individualsContainer)
individualsContainer:Attach(individualsBracketContainer,1)
individualsBracketContainer:SetPosition(0,0)

local individualSelectionImage = CreateFrame("image", "individualSelectionImage", 3230, 4206)
individualSelectionImage:SetPosition(0, -0.02)
individualSelectionImage:SetSize(individualsContainer:GetSize())
individualSelectionImage:SetBackgroundColour(0.0, 0.0, 0.0, 0.5)
individualsContainer:Attach(individualSelectionImage)




local individuals1Container = CreateFrame("container", "individuals1Container", 3004)
individuals1Container:SetPosition(individualsBracketLength, individualsContainerHeight-individualsImageHeight-0.005)
individuals1Container:SetSize(individualsImageWidth, individualsImageHeight)
--individuals1Container:Renderable(true)
--individuals1Container:SetBackgroundColour(0.0, 1.0, 1.0, 1.0)
individualsContainer:Attach(individuals1Container)


local individuals1ImageContainer = CreateFrame("container", "individuals1ImageContainer", 3017)
individuals1ImageContainer:SetPosition(0.0,  0.0)
individuals1ImageContainer:SetSize(individuals1Container:GetSize())
local individuals1ImageUp = CreateFrame("image", "individuals1ImageUp", 3217, 3217)
individuals1ImageUp:SetPosition(0.0, 0.0)
individuals1ImageUp:SetSize(individuals1ImageContainer:GetSize())
local individuals1ImageOver = CreateFrame("image", "individuals1ImageOver", 3218, 3218)
individuals1ImageOver:SetPosition(0.0, 0.0)
individuals1ImageOver:SetSize(individuals1ImageContainer:GetSize())
individuals1ImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local individuals1ImageDown = CreateFrame("image", "individuals1ImageDown", 3219, 3219)
individuals1ImageDown:SetPosition(0.0, 0.0)
individuals1ImageDown:SetSize(individuals1ImageContainer:GetSize())
local individuals1Button = CreateFrame("button", "individuals1Button", 3307)
individuals1Button:TabIndex(204)
individuals1Button:SetPosition(0.0, 0.0)
individuals1Button:SetSize(individuals1ImageContainer:GetSize())
individuals1Button:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individuals1Button:SetBorderColour(0.0, 0.0, 0.0, 0.0)
individuals1ImageUp:Visible(true)
individuals1ImageOver:Visible(false)
individuals1ImageDown:Visible(false)
individuals1ImageContainer:Attach(individuals1Button)
individuals1ImageContainer:Attach(individuals1ImageUp)
individuals1ImageContainer:Attach(individuals1ImageOver)
individuals1ImageContainer:Attach(individuals1ImageDown)
individuals1Container:Attach(individuals1ImageContainer)



local individualsBarHorizontalDisplacement = 0.05
local individualsNameVerticalDisplacement = 0.04
local individualsNameHorizontalDisplacement = 0.05
local individualsNameTextSize = 0.06

local individuals1Name = CreateFrame("label", "individuals1Name", 3130, 2) 
individuals1Name:SetText(animals[animal_state["specy"]][0]["NAME"])
individuals1Name:SetPosition(individualsNameHorizontalDisplacement, (individualsImageHeight-individualsNameTextSize)/2+individualsNameVerticalDisplacement)
individuals1Name:SetSize(0.45, individualsNameTextSize)
individuals1Name:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individuals1Name:SetBorderColour(0, 0, 0, 0)
individuals1Container:Attach(individuals1Name)


local individuals1BarContainer = CreateFrame("container", "individuals1BarContainer", 3005)
individuals1BarContainer:SetPosition(individualsImageWidth/2+individualsBarHorizontalDisplacement, individualsBarsPaddingY+individualsImageHeight-3*(individualsImageHeight/5+individualsBarsPaddingY))
individuals1BarContainer:SetSize(individualsBarMaxWidth, individualsBarContainerHeight)
individuals1Container:Attach(individuals1BarContainer)

local individuals1eBar = CreateFrame("label", "individuals1eBar", 3121, 1)
individuals1eBar:SetPosition(0, individualsBarContainerHeight-individualsBarMaxHeight-individualsBarsPaddingY)
individuals1eBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals1eBar:SetBackgroundColour(0.0, 1.0, 0.0, 1.0)
individuals1eBar:SetBorderColour(0, 0, 0, 0)
individuals1BarContainer:Attach(individuals1eBar)

local individuals1dBar = CreateFrame("label", "individuals1dBar", 3122, 1)
individuals1dBar:SetPosition(0, individualsBarContainerHeight-2*(individualsBarMaxHeight+individualsBarsPaddingY))
individuals1dBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals1dBar:SetBackgroundColour(0.0, 0.0, 1.0, 1.0)
individuals1dBar:SetBorderColour(0, 0, 0, 0)
individuals1BarContainer:Attach(individuals1dBar)

local individuals1mBar = CreateFrame("label", "individuals1mBar", 3123, 1)
individuals1mBar:SetPosition(0, individualsBarContainerHeight-3*(individualsBarMaxHeight+individualsBarsPaddingY))
individuals1mBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals1mBar:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
individuals1mBar:SetBorderColour(0, 0, 0, 0)
individuals1BarContainer:Attach(individuals1mBar)


local individuals2Container = CreateFrame("container", "individuals2Container", 3006)
individuals2Container:SetPosition(individualsBracketLength, individualsContainerHeight-2*(individualsImageHeight+individualsPaddingY)+0.02)
individuals2Container:SetSize(individualsImageWidth, individualsImageHeight)
--individuals2Container:Renderable(true)
--individuals2Container:SetBackgroundColour(1.0, 1.0, 1.0, 1.0)
individualsContainer:Attach(individuals2Container)


local individuals2ImageContainer = CreateFrame("container", "individuals2ImageContainer", 3018)
individuals2ImageContainer:SetPosition(0.0,  0.0)
individuals2ImageContainer:SetSize(individuals2Container:GetSize())
local individuals2ImageUp = CreateFrame("image", "individuals2ImageUp", 3221, 3217)
individuals2ImageUp:SetPosition(0.0, 0.0)
individuals2ImageUp:SetSize(individuals2ImageContainer:GetSize())
local individuals2ImageOver = CreateFrame("image", "individuals2ImageOver", 3222, 3218)
individuals2ImageOver:SetPosition(0.0, 0.0)
individuals2ImageOver:SetSize(individuals2ImageContainer:GetSize())
individuals2ImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local individuals2ImageDown = CreateFrame("image", "individuals2ImageDown", 3223, 3219)
individuals2ImageDown:SetPosition(0.0, 0.0)
individuals2ImageDown:SetSize(individuals2ImageContainer:GetSize())
local individuals2Button = CreateFrame("button", "individuals2Button", 3308)
individuals2Button:TabIndex(205)
individuals2Button:SetPosition(0.0, 0.0)
individuals2Button:SetSize(individuals2ImageContainer:GetSize())
individuals2Button:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individuals2Button:SetBorderColour(0.0, 0.0, 0.0, 0.0)
individuals2ImageUp:Visible(true)
individuals2ImageOver:Visible(false)
individuals2ImageDown:Visible(false)
individuals2ImageContainer:Attach(individuals2Button)
individuals2ImageContainer:Attach(individuals2ImageUp)
individuals2ImageContainer:Attach(individuals2ImageOver)
individuals2ImageContainer:Attach(individuals2ImageDown)
individuals2Container:Attach(individuals2ImageContainer)


local individuals2Name = CreateFrame("label", "individuals2Name", 3131, 2)
individuals2Name:SetText(animals[animal_state["specy"]][1]["NAME"])
individuals2Name:SetPosition(individualsNameHorizontalDisplacement, (individualsImageHeight-individualsNameTextSize)/2+individualsNameVerticalDisplacement)
individuals2Name:SetSize(0.45, individualsNameTextSize)
individuals2Name:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individuals2Name:SetBorderColour(0, 0, 0, 0)
individuals2Container:Attach(individuals2Name)

local individuals2BarContainer = CreateFrame("container", "individuals2BarContainer", 3007)
individuals2BarContainer:SetPosition(individualsImageWidth/2+individualsBarHorizontalDisplacement, individualsBarsPaddingY+individualsImageHeight-3*(individualsImageHeight/5+individualsBarsPaddingY))
individuals2BarContainer:SetSize(individualsBarMaxWidth, individualsBarContainerHeight)
individuals2Container:Attach(individuals2BarContainer)

local individuals2eBar = CreateFrame("label", "individuals2eBar", 3124, 1)
individuals2eBar:SetPosition(0, individualsBarContainerHeight-individualsBarMaxHeight-individualsBarsPaddingY)
individuals2eBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals2eBar:SetBackgroundColour(0.0, 1.0, 0.0, 1.0)
individuals2eBar:SetBorderColour(0, 0, 0, 0)
individuals2BarContainer:Attach(individuals2eBar)

local individuals2dBar = CreateFrame("label", "individuals2dBar", 3125, 1)
individuals2dBar:SetPosition(0, individualsBarContainerHeight-2*(individualsBarMaxHeight+individualsBarsPaddingY))
individuals2dBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals2dBar:SetBackgroundColour(0.0, 0.0, 1.0, 1.0)
individuals2dBar:SetBorderColour(0, 0, 0, 0)
individuals2BarContainer:Attach(individuals2dBar)

local individuals2mBar = CreateFrame("label", "individuals2mBar", 3126, 1)
individuals2mBar:SetPosition(0, individualsBarContainerHeight-3*(individualsBarMaxHeight+individualsBarsPaddingY))
individuals2mBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals2mBar:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
individuals2mBar:SetBorderColour(0, 0, 0, 0)
individuals2BarContainer:Attach(individuals2mBar)



local individuals3Container = CreateFrame("container", "individuals3Container", 3008)
individuals3Container:SetPosition(individualsBracketLength, individualsContainerHeight-3*(individualsImageHeight+individualsPaddingY)+0.02)
individuals3Container:SetSize(individualsImageWidth, individualsImageHeight)
--individuals3Container:Renderable(true)
--individuals3Container:SetBackgroundColour(1.0, 0.0, 1.0, 1.0)
individualsContainer:Attach(individuals3Container)


local individuals3ImageContainer = CreateFrame("container", "individuals3ImageContainer", 3019)
individuals3ImageContainer:SetPosition(0.0,  0.0)
individuals3ImageContainer:SetSize(individuals3Container:GetSize())
local individuals3ImageUp = CreateFrame("image", "individuals3ImageUp", 3225, 3217)
individuals3ImageUp:SetPosition(0.0, 0.0)
individuals3ImageUp:SetSize(individuals3ImageContainer:GetSize())
local individuals3ImageOver = CreateFrame("image", "individuals3ImageOver", 3226, 3218)
individuals3ImageOver:SetPosition(0.0, 0.0)
individuals3ImageOver:SetSize(individuals3ImageContainer:GetSize())
individuals3ImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local individuals3ImageDown = CreateFrame("image", "individuals3ImageDown", 3227, 3219)
individuals3ImageDown:SetPosition(0.0, 0.0)
individuals3ImageDown:SetSize(individuals3ImageContainer:GetSize())
local individuals3Button = CreateFrame("button", "individuals3Button", 3309)
individuals3Button:TabIndex(206)
individuals3Button:SetPosition(0.0, 0.0)
individuals3Button:SetSize(individuals3ImageContainer:GetSize())
individuals3Button:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individuals3Button:SetBorderColour(0.0, 0.0, 0.0, 0.0)
individuals3ImageUp:Visible(true)
individuals3ImageOver:Visible(false)
individuals3ImageDown:Visible(false)
individuals3ImageContainer:Attach(individuals3Button)
individuals3ImageContainer:Attach(individuals3ImageUp)
individuals3ImageContainer:Attach(individuals3ImageOver)
individuals3ImageContainer:Attach(individuals3ImageDown)
individuals3Container:Attach(individuals3ImageContainer)


local individuals3Name = CreateFrame("label", "individuals3Name", 3132, 2)
individuals3Name:SetText(animals[animal_state["specy"]][2]["NAME"])
individuals3Name:SetPosition(individualsNameHorizontalDisplacement, (individualsImageHeight-individualsNameTextSize)/2+individualsNameVerticalDisplacement)
individuals3Name:SetSize(0.45, individualsNameTextSize)
individuals3Name:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individuals3Name:SetBorderColour(0, 0, 0, 0)
individuals3Container:Attach(individuals3Name)

local individuals3BarContainer = CreateFrame("container", "individuals3BarContainer", 3009)
individuals3BarContainer:SetPosition(individualsImageWidth/2+individualsBarHorizontalDisplacement, individualsBarsPaddingY+individualsImageHeight-3*(individualsImageHeight/5+individualsBarsPaddingY))
individuals3BarContainer:SetSize(individualsBarMaxWidth, individualsBarContainerHeight)
individuals3Container:Attach(individuals3BarContainer)

local individuals3eBar = CreateFrame("label", "individuals3eBar", 3127, 1)
individuals3eBar:SetPosition(0, individualsBarContainerHeight-individualsBarMaxHeight-individualsBarsPaddingY)
individuals3eBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals3eBar:SetBackgroundColour(0.0, 1.0, 0.0, 1.0)
individuals3eBar:SetBorderColour(0, 0, 0, 0)
individuals3BarContainer:Attach(individuals3eBar)

local individuals3dBar = CreateFrame("label", "individuals3dBar", 3128, 1)
individuals3dBar:SetPosition(0, individualsBarContainerHeight-2*(individualsBarMaxHeight+individualsBarsPaddingY))
individuals3dBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals3dBar:SetBackgroundColour(0.0, 0.0, 1.0, 1.0)
individuals3dBar:SetBorderColour(0, 0, 0, 0)
individuals3BarContainer:Attach(individuals3dBar)

local individuals3mBar = CreateFrame("label", "individuals3mBar", 3129, 1)
individuals3mBar:SetPosition(0, individualsBarContainerHeight-3*(individualsBarMaxHeight+individualsBarsPaddingY))
individuals3mBar:SetSize(individualsBarMaxWidth, individualsBarMaxHeight)
individuals3mBar:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
individuals3mBar:SetBorderColour(0, 0, 0, 0)
individuals3BarContainer:Attach(individuals3mBar)



local individualsUpContainer = CreateFrame("container", "individualsUpContainer", 3015)
individualsUpContainer:SetPosition(0.95,  1.035)
individualsUpContainer:SetSize(0.6, 0.2)
local individualsUpImageUp = CreateFrame("image", "individualsUpImageUp", 3213, 3213)
individualsUpImageUp:SetPosition(0.0, 0.0)
individualsUpImageUp:SetSize(0.6, 0.6)
local individualsUpImageOver = CreateFrame("image", "individualsUpImageOver", 3214, 3214)
individualsUpImageOver:SetPosition(0.0, 0.0)
individualsUpImageOver:SetSize(0.6, 0.6)
individualsUpImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local individualsUpButton = CreateFrame("button", "individualsUpButton", 3305)
individualsUpButton:TabIndex(203)
individualsUpButton:SetPosition(0.0, 0.0)
individualsUpButton:SetSize(individualsUpContainer:GetSize())
individualsUpButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individualsUpButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
individualsUpImageOver:Visible(false)
individualsUpImageUp:Visible(true)
individualsUpContainer:Attach(individualsUpButton)
individualsUpContainer:Attach(individualsUpImageUp)
individualsUpContainer:Attach(individualsUpImageOver)
animalSelectionContainer:Attach(individualsUpContainer)

local individualsDownContainer = CreateFrame("container", "individualsDownContainer", 3016)
individualsDownContainer:SetPosition(0.95,  0.165)
individualsDownContainer:SetSize(0.6, 0.2)
local individualsDownImageUp = CreateFrame("image", "individualsDownImageUp", 3215, 3215)
individualsDownImageUp:SetPosition(0.0, 0.0)
individualsDownImageUp:SetSize(0.6, 0.6)
local individualsDownImageOver = CreateFrame("image", "individualsDownImageOver", 3216, 3216)
individualsDownImageOver:SetPosition(0.0, 0.0)
individualsDownImageOver:SetSize(0.6, 0.6)
individualsDownImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local individualsDownButton = CreateFrame("button", "individualsDownButton", 3306)
individualsDownButton:TabIndex(207)
individualsDownButton:SetPosition(0.0, 0.0)
individualsDownButton:SetSize(individualsDownContainer:GetSize())
individualsDownButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
individualsDownButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
individualsDownImageOver:Visible(false)
individualsDownImageUp:Visible(true)
individualsDownContainer:Attach(individualsDownButton)
individualsDownContainer:Attach(individualsDownImageUp)
individualsDownContainer:Attach(individualsDownImageOver)
animalSelectionContainer:Attach(individualsDownContainer)


local animalSelectionBackContainer = CreateFrame("container", "animalSelectionBackContainer", 3010)
animalSelectionBackContainer:SetSize(0.3, 0.15)
--animalSelectionBackContainer:SetPosition(0.55, 0.05)
animalSelectionBackContainer:SetPosition((animalSelectionContainerWidth-nextAndBackDistance)/2-select(1, animalSelectionBackContainer:GetSize()), 0.05)
local animalSelectionBackButton = CreateFrame("button", "animalSelectionBackButton", 3300)
animalSelectionBackButton:TabIndex(209)
animalSelectionBackButton:SetPosition(0.0, 0.0)
animalSelectionBackButton:SetSize(animalSelectionBackContainer:GetSize())
animalSelectionBackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
animalSelectionBackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
animalSelectionBackContainer:Attach(animalSelectionBackButton)
local animalSelectionBackImageUP = CreateFrame("image", "animalSelectionBackImageUP", 3209, 5204)
animalSelectionBackImageUP:SetPosition(0.0, 0.0)
animalSelectionBackImageUP:SetSize(animalSelectionBackContainer:GetSize())
animalSelectionBackContainer:Attach(animalSelectionBackImageUP)
local animalSelectionBackImageOVER = CreateFrame("image", "animalSelectionBackImageOVER", 3210, 5205)
animalSelectionBackImageOVER:SetPosition(0.0, 0.0)
animalSelectionBackImageOVER:SetSize(animalSelectionBackContainer:GetSize())
animalSelectionBackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
animalSelectionBackContainer:Attach(animalSelectionBackImageOVER)
animalSelectionContainer:Attach(animalSelectionBackContainer)
animalSelectionBackImageOVER:Visible(false)
animalSelectionBackImageUP:Visible(true)

local animalSelectionNextContainer = CreateFrame("container", "animalSelectionNextContainer", 3011)
animalSelectionNextContainer:SetSize(0.3, 0.15)
--animalSelectionNextContainer:SetPosition(0.9, 0.05)
--animalSelectionNextContainer:SetPosition((animalSelectionContainerWidth-nextAndBackDistance)/2, 0.05)
animalSelectionNextContainer:SetPosition((animalSelectionContainerWidth+nextAndBackDistance)/2, 0.05)

local animalSelectionNextButton = CreateFrame("button", "animalSelectionNextButton", 3301)
animalSelectionNextButton:TabIndex(208)
animalSelectionNextButton:SetPosition(0.0, 0.0)
animalSelectionNextButton:SetSize(animalSelectionNextContainer:GetSize())
animalSelectionNextButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
animalSelectionNextButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
animalSelectionNextContainer:Attach(animalSelectionNextButton)
local animalSelectionNextImageUP = CreateFrame("image", "animalSelectionNextImageUP", 3211, 3220)
animalSelectionNextImageUP:SetPosition(0.0, 0.0)
animalSelectionNextImageUP:SetSize(animalSelectionNextContainer:GetSize())
animalSelectionNextContainer:Attach(animalSelectionNextImageUP)
local animalSelectionNextImageOVER = CreateFrame("image", "animalSelectionNextImageOVER", 3212, 3221)
animalSelectionNextImageOVER:SetPosition(0.0, 0.0)
animalSelectionNextImageOVER:SetSize(animalSelectionNextContainer:GetSize())
animalSelectionNextContainer:Attach(animalSelectionNextImageOVER)
animalSelectionContainer:Attach(animalSelectionNextContainer)
animalSelectionNextContainer:Visible(false)
animalSelectionNextImageOVER:Visible(false)
animalSelectionNextImageUP:Visible(true)


speciesBracketContainer:SetPosition(speciesPosX-speciesBracketLength, firstSpeciesPosY)
individualsBracketContainer:SetPosition(0, 1.0-individualsImageHeight)



function recompute_edm_width()
	local firstE = tonumber(animals[animal_state["specy"]][individuals_top_index]["E"])
	local firstD = tonumber(animals[animal_state["specy"]][individuals_top_index]["D"])
	local firstM = tonumber(animals[animal_state["specy"]][individuals_top_index]["M"])

	local secondE = tonumber(animals[animal_state["specy"]][individuals_top_index+1]["E"])
	local secondD = tonumber(animals[animal_state["specy"]][individuals_top_index+1]["D"])
	local secondM = tonumber(animals[animal_state["specy"]][individuals_top_index+1]["M"])

	local thirdE = tonumber(animals[animal_state["specy"]][individuals_top_index+2]["E"])
	local thirdD = tonumber(animals[animal_state["specy"]][individuals_top_index+2]["D"])
	local thirdM = tonumber(animals[animal_state["specy"]][individuals_top_index+2]["M"])

	local barH = select(2, individuals1eBar:GetSize())
	individuals1eBar:SetSize((firstE-min_e_value)/(max_e_value-min_e_value)*individualsBarMaxWidth, barH)
	individuals1dBar:SetSize((firstD-min_d_value)/(max_d_value-min_d_value)*individualsBarMaxWidth, barH)
	individuals1mBar:SetSize((firstM-min_m_value)/(max_m_value-min_m_value)*individualsBarMaxWidth, barH)

	individuals2eBar:SetSize((secondE-min_e_value)/(max_e_value-min_e_value)*individualsBarMaxWidth, barH)
	individuals2dBar:SetSize((secondD-min_d_value)/(max_d_value-min_d_value)*individualsBarMaxWidth, barH)
	individuals2mBar:SetSize((secondM-min_m_value)/(max_m_value-min_m_value)*individualsBarMaxWidth, barH)

	individuals3eBar:SetSize((thirdE-min_e_value)/(max_e_value-min_e_value)*individualsBarMaxWidth, barH)
	individuals3dBar:SetSize((thirdD-min_d_value)/(max_d_value-min_d_value)*individualsBarMaxWidth, barH)
	individuals3mBar:SetSize((thirdM-min_m_value)/(max_m_value-min_m_value)*individualsBarMaxWidth, barH)

	individuals1Name:SetText(animals[animal_state["specy"]][individuals_top_index]["NAME"])
	individuals2Name:SetText(animals[animal_state["specy"]][individuals_top_index+1]["NAME"])
	individuals3Name:SetText(animals[animal_state["specy"]][individuals_top_index+2]["NAME"])

	
	if pack_test[individuals1Name:GetText()] == 1 then
		individuals1ImageUp:Visible(false)
		individuals1ImageOver:Visible(false)
		individuals1ImageDown:Visible(true)
	else
		individuals1ImageUp:Visible(true)
		individuals1ImageOver:Visible(false)
		individuals1ImageDown:Visible(false)
	end
	if pack_test[individuals2Name:GetText()] == 1 then
		individuals2ImageUp:Visible(false)
		individuals2ImageOver:Visible(false)
		individuals2ImageDown:Visible(true)
	else
		individuals2ImageUp:Visible(true)
		individuals2ImageOver:Visible(false)
		individuals2ImageDown:Visible(false)
	end
	if pack_test[individuals3Name:GetText()] == 1 then
		individuals3ImageUp:Visible(false)
		individuals3ImageOver:Visible(false)
		individuals3ImageDown:Visible(true)
	else
		individuals3ImageUp:Visible(true)
		individuals3ImageOver:Visible(false)
		individuals3ImageDown:Visible(false)
	end
end

function disableOthersSpecies(sp)
	for k in pairs (animal_state["pack"]) do
		pack_test[animal_state["pack"][k]] = 0
		animal_state["pack"][k] = nil
	end
	if animal_state["specy"] ~= species[sp] then
		--selectYourAnimalLabel:SetText("Select Your 4 Animals")
		selectYourAnimalLabel:SetText("Select Your 4 Animals")
		animalsInPackLabel:SetText(animalsInPackText.."0")
		if animalPackIsComplete then
			TriggerEvent(PLAY_UNGO)
		end
		animalPackIsComplete = false
		animalSelectionNextContainer:Visible(false)
		animalSelectionNextHasFocus = false
		played_go = false
		individuals_top_index = 0
	end
	if sp == 1 then
		dogSpeciesImageDOWN:Visible(true)
		dogSpeciesImageUP:Visible(false)
		dogSpeciesImageOVER:Visible(false)
		mouseSpeciesImageUP:Visible(true)
		mouseSpeciesImageOVER:Visible(false)
		mouseSpeciesImageDOWN:Visible(false)
		dinoSpeciesImageUP:Visible(true)
		dinoSpeciesImageOVER:Visible(false)
		dinoSpeciesImageDOWN:Visible(false)
	elseif sp == 2 then
		mouseSpeciesImageDOWN:Visible(true)
		mouseSpeciesImageUP:Visible(false)
		mouseSpeciesImageOVER:Visible(false)
		dogSpeciesImageUP:Visible(true)
		dogSpeciesImageOVER:Visible(false)
		dogSpeciesImageDOWN:Visible(false)
		dinoSpeciesImageUP:Visible(true)
		dinoSpeciesImageOVER:Visible(false)
		dinoSpeciesImageDOWN:Visible(false)
	elseif sp == 3 then
		dinoSpeciesImageDOWN:Visible(true)
		dinoSpeciesImageUP:Visible(false)
		dinoSpeciesImageOVER:Visible(false)
		dogSpeciesImageUP:Visible(true)
		dogSpeciesImageOVER:Visible(false)
		dogSpeciesImageDOWN:Visible(false)
		mouseSpeciesImageUP:Visible(true)
		mouseSpeciesImageOVER:Visible(false)
		mouseSpeciesImageDOWN:Visible(false)
	end
end

function printPack()
	print("--pack--")
	for _,v in ipairs(animal_state["pack"]) do print(_,v) end
	print("-------")
end

function addToPack(name, UP, OVER, DOWN)
	if pack_test[name:GetText()] == 1 then
		for i,v in ipairs(animal_state["pack"]) do 
			if v == name:GetText() then 
				table.remove(animal_state["pack"], i)
				pack_test[name:GetText()] = 0
				break
			end
		end
		if animalPackIsComplete then
			TriggerEvent(PLAY_UNGO)
		end		
		animalPackIsComplete = false 
		animalSelectionNextContainer:Visible(false)
		played_go = false
		animalSelectionNextHasFocus = false

		UP:Visible(true)
		OVER:Visible(true)
		DOWN:Visible(false)
	else
		--if #animal_state["pack"] < 4 then
		if not animalPackIsComplete then
			table.insert(animal_state["pack"], name:GetText())
			pack_test[name:GetText()] = 1
			UP:Visible(false)
			OVER:Visible(false)
			DOWN:Visible(true)
		end
		if #animal_state["pack"] == 4 then 
			animalPackIsComplete = true
			animalSelectionNextContainer:Visible(true)
		end
	end

	local packCounter = #animal_state["pack"]
	animalsInPackLabel:SetText(animalsInPackText..packCounter)
	if not animalPackIsComplete then
		selectYourAnimalLabel:SetText("Select Your 4 Animals")
	else
		if not played_go then
			TriggerEvent(PLAY_GO)
			played_go = true
		end
		selectYourAnimalLabel:SetText("Your Pack Is Ready")
		TriggerEvent(COMPONENT_REQUEST_FOCUS, animalSelectionNextButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
	--printPack()
end


animalSelectionButtonCycleStart = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }
animalSelectionButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
animalSelectionButtonCycleDoAnimation = { false, false, false, false, false, false, false, false, false }
animalSelectionButtonCycleAnimationOver = { false, false, false, false, false, false, false, false, false }


individuals1Button:EventFunction(function(self, e, ...)
	if not individuals1ImageDown:IsVisible() then
		--swapImages(e, individuals1ImageUp, individuals1ImageOver)
		individuals1ImageOver:Visible(true)
		buttonOver(e, 1, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, individuals1ImageOver)
	end
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		addToPack(individuals1Name, individuals1ImageUp, individuals1ImageOver, individuals1ImageDown)
	elseif e == COMPONENT_ON_FOCUS_GAINED then
		speciesBracketContainer:Visible(false)
		individualsBracketContainer:Visible(true)
		individualsBracketContainer:SetPosition(0, individualsContainerHeight-individualsImageHeight-0.005)
	end
end)

individuals2Button:EventFunction(function(self, e, ...)
	if not individuals2ImageDown:IsVisible() then
		--swapImages(e, individuals2ImageUp, individuals2ImageOver)
		individuals2ImageOver:Visible(true)
		buttonOver(e, 2, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, individuals2ImageOver)
	end
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		addToPack(individuals2Name, individuals2ImageUp, individuals2ImageOver, individuals2ImageDown)
	elseif e == COMPONENT_ON_FOCUS_GAINED then
		speciesBracketContainer:Visible(false)
		individualsBracketContainer:Visible(true)
		individualsBracketContainer:SetPosition(0, individualsContainerHeight-2*(individualsImageHeight+individualsPaddingY)+0.02)
	end
end)

individuals3Button:EventFunction(function(self, e, ...)
	if not individuals3ImageDown:IsVisible() then	
		--swapImages(e, individuals3ImageUp, individuals3ImageOver)
		individuals3ImageOver:Visible(true)
		buttonOver(e, 3, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, individuals3ImageOver)
	end
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		addToPack(individuals3Name, individuals3ImageUp, individuals3ImageOver, individuals3ImageDown)
	elseif e == COMPONENT_ON_FOCUS_GAINED then
		speciesBracketContainer:Visible(false)
		individualsBracketContainer:Visible(true)
		individualsBracketContainer:SetPosition(0, individualsContainerHeight-3*(individualsImageHeight+individualsPaddingY)+0.02)
	end
end)


individualsUpButton:EventFunction(function(self, e, ...)
	--swapImages(e, individualsUpImageUp, individualsUpImageOver)
	individualsUpImageOver:Visible(true)
	buttonOver(e, 4, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, individualsUpImageOver)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		if individuals_top_index >= 1 then
			individuals_top_index = individuals_top_index - 1
			recompute_edm_width()
		end
	end
end)

individualsDownButton:EventFunction(function(self, e, ...)
	--swapImages(e, individualsDownImageUp, individualsDownImageOver)
	individualsDownImageOver:Visible(true)
	buttonOver(e, 5, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, individualsDownImageOver)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		if individuals_top_index < ANIMAL_INDIVIDUALS_COUNT-3 then
			individuals_top_index = individuals_top_index + 1
			recompute_edm_width()
		end
	end
end)

animalSelectionBackButton:EventFunction(function(self, e, ...)
	--swapImages(e, animalSelectionBackImageUP, animalSelectionBackImageOVER)
	animalSelectionBackImageOVER:Visible(true)
	buttonOver(e, 6, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, animalSelectionBackImageOVER)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		animalSelectionContainer:Visible(false)
		trackContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, trackSelectionNextButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

local animalSelectionNextButtonCycleStart = 0
local animalSelectionNextButtonCycleDuration = 1000
animalSelectionNextImageUP:Visible(true)
animalSelectionNextImageOVER:Visible(true)



animalSelectionNextButton:EventFunction(function(self, e, ...)
	--swapImages(e, animalSelectionNextImageUP, animalSelectionNextImageOVER)

	if e == COMPONENT_ON_FOCUS_GAINED then
		animalSelectionNextHasFocus = true
	elseif e == COMPONENT_ON_FOCUS_LOST then
		animalSelectionNextHasFocus = false
		animalSelectionNextImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
	end
	if animalPackIsComplete and animalSelectionNextHasFocus then
		local t = time("mlsec")
		local totalTime = t - animalSelectionNextButtonCycleStart
		if totalTime > animalSelectionNextButtonCycleDuration then
			animalSelectionNextButtonCycleStart = t
		end
		local fraction = totalTime/animalSelectionNextButtonCycleDuration --off and gradually on
		fraction = 1 - math.abs(1 - (2 * fraction)) --pulse effect
		animalSelectionNextImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, fraction)
	else
		--animalSelectionNextImageUP:Visible(true)
		--animalSelectionNextImageOVER:Visible(false)
		animalSelectionNextImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
	end
	if e == COMPONENT_ACTION_PERFORMED and #animal_state["pack"] == 4 then
		playDefaultButtonSoundFX(e)
		animalSelectionContainer:Visible(false)
		menuUIStuffContainer:Visible(false)
		gameStuffContainer:Visible(true)
		if cursorWidgetImage ~= nil then cursorWidgetImage:Visible(false) end
		--TriggerEvent(FETCH_MENU_PARAMS, game_state["playername"], game_state["racetype"], game_state["course"], game_state["specy"], animal_state["pack"][1], animal_state["pack"][2], animal_state["pack"][3], animal_state["pack"][4], game_state["difficulty"])
		TriggerEvent(FETCH_MENU_PARAMS, game_state["playername"], game_state["racetype"], "<RESERVED>", game_state["specy"], animal_state["pack"][1], animal_state["pack"][2], animal_state["pack"][3], animal_state["pack"][4], game_state["difficulty"], game_state["course"]["data"], game_state["course"]["scenerystart"], game_state["course"]["groundid"], game_state["course"]["audioid"], game_state["course"]["godmode"])
	end
end)

dogSpeciesButton:EventFunction(function(self, e, ...)
	if e == COMPONENT_ON_FOCUS_GAINED then
		individualsBracketContainer:Visible(false)
		speciesBracketContainer:Visible(true)
		speciesBracketContainer:SetPosition(speciesPosX-speciesBracketLength, firstSpeciesPosY)
	end
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		disableOthersSpecies(1)
		animal_state["specy"] = species[1]
		game_state["specy"] = species[1]
		recompute_edm_width()
	elseif dogSpeciesImageDOWN:IsVisible() ~= true then
		--swapImages(e, dogSpeciesImageUP, dogSpeciesImageOVER)
		dogSpeciesImageOVER:Visible(true)
		buttonOver(e, 7, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, dogSpeciesImageOVER)
	end
end)

mouseSpeciesButton:EventFunction(function(self, e, ...)
	if e == COMPONENT_ON_FOCUS_GAINED then
		individualsBracketContainer:Visible(false)
		speciesBracketContainer:Visible(true)
		speciesBracketContainer:SetPosition(speciesPosX-speciesBracketLength, firstSpeciesPosY-(speciesImageHeight+2*speciesBracketWidth))
	end
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		disableOthersSpecies(2)
		animal_state["specy"] = species[2]
		game_state["specy"] = species[2]
		recompute_edm_width()
	elseif mouseSpeciesImageDOWN:IsVisible() ~= true then
		--swapImages(e, mouseSpeciesImageUP, mouseSpeciesImageOVER)
		mouseSpeciesImageOVER:Visible(true)
		buttonOver(e, 8, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, mouseSpeciesImageOVER)
	end
end)

dinoSpeciesButton:EventFunction(function(self, e, ...)
	if e == COMPONENT_ON_FOCUS_GAINED then
		individualsBracketContainer:Visible(false)
		speciesBracketContainer:Visible(true)
		speciesBracketContainer:SetPosition(speciesPosX-speciesBracketLength, firstSpeciesPosY-2*(speciesImageHeight+2*speciesBracketWidth))
	end
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		disableOthersSpecies(3)
		animal_state["specy"] = species[3]
		game_state["specy"] = species[3]
		recompute_edm_width()
	elseif dinoSpeciesImageDOWN:IsVisible() ~= true then
		--swapImages(e, dinoSpeciesImageUP, dinoSpeciesImageOVER)
		dinoSpeciesImageOVER:Visible(true)
		buttonOver(e, 9, animalSelectionButtonCycleStart, animalSelectionButtonCycleDuration, animalSelectionButtonCycleDoAnimation, animalSelectionButtonCycleAnimationOver, dinoSpeciesImageOVER)
	end
end)


recompute_edm_width()
animalSelectionContainer:Visible(false)
UIRoot:Attach(animalSelectionContainer)
