--this file uses components IDs from [7000 to 8000[ and tabindices from [600 to 700[

local splash1Container = CreateFrame("container", "splash1Container", 7000)
splash1Container:SetPosition(0.1, 0.1)
splash1Container:SetSize(1.8, 1.8)

local splash1Width = 0.75
local splash1Height = 0.75

local splash1Image = CreateFrame("image", "splash1Image", 7100, 7100);
splash1Image:SetPosition((select(1, splash1Container:GetSize())-splash1Width)/2, (select(2, splash1Container:GetSize())-splash1Height)/2)
splash1Image:SetSize(splash1Width, splash1Height) 
splash1Container:Attach(splash1Image)

splash1Container:Visible(true)

local splash1duration = 2.5 --secs
--local splash1currentTime = 0
local splash1currentTime = -10

splash1Container:EventFunction(function(self, e, ...)
	if e == UPDATE and splash1Container:IsVisible() then
		if splash1currentTime < 0 then
			splash1currentTime = 0
			TriggerEvent(PLAY_MENU_MUSIC)
		end
		splash1currentTime = splash1currentTime + select(1, ...)
		if splash1currentTime >= splash1duration then
			splash1currentTime = -10
			splash1Container:Visible(false)
			splash2Container:Visible(true)
		end
	end	
end)

UIRoot:Attach(splash1Container)