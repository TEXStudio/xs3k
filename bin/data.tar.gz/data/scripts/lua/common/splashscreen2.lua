--this file uses components IDs from [8000 to 9000[ and tabindices from [700 to 800[

local splash2Container = CreateFrame("container", "splash2Container", 8000)
splash2Container:SetPosition(0.0, 0.0)
splash2Container:SetSize(2.0, 2.0)
splash2Container:Renderable(true)
splash2Container:RenderBorder(true)
splash2Container:SetBackgroundColour(0.66, 0.66, 0.66, 0.0)
splash2Container:SetBorderColour(0.0, 0.0, 0.0, 0.0)

local splash2Image = CreateFrame("image", "splash2Image", 8100, 8100);
splash2Image:SetPosition(0.0, 0.0)
splash2Image:SetSize(splash2Container:GetSize())
splash2Container:Attach(splash2Image)


local bulletLogo = CreateFrame("image", "bulletLogo", 8101, 8101);
bulletLogo:SetPosition(1.25, 1.1)
bulletLogo:SetSize(0.5, 0.25)
splash2Container:Attach(bulletLogo)

local luaLogo = CreateFrame("image", "luaLogo", 8102, 8102);
luaLogo:SetPosition(0.0, 0.6)
luaLogo:SetSize(0.25, 0.25*16.0/9.0)
splash2Container:Attach(luaLogo)

local openglLogo = CreateFrame("image", "openglLogo", 8103, 8103);
openglLogo:SetPosition(1.3, 0.1)
openglLogo:SetSize(0.4, 0.2)
splash2Container:Attach(openglLogo)

local nvidiaLogo = CreateFrame("image", "nvidiaLogo", 8104, 8104);
nvidiaLogo:SetPosition(0.35, 0.1)
nvidiaLogo:SetSize(0.4, 0.2)
splash2Container:Attach(nvidiaLogo)

local fmodLogo = CreateFrame("image", "fmodLogo", 8105, 8105);
fmodLogo:SetPosition(0.0, 1.1)
fmodLogo:SetSize(0.5, 0.25)
splash2Container:Attach(fmodLogo)





local gameVersionLabel = CreateFrame("label", "gameVersionLabel", 8200, 2)
gameVersionLabel:SetText("v"..GAME_VERSION)
gameVersionLabel:SetSize(0.35, 0.045)
gameVersionLabel:SetPosition(select(1, splash2Container:GetSize())-select(1, gameVersionLabel:GetSize())+0.15, select(2, splash2Container:GetSize())-0.045)

gameVersionLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
splash2Container:Attach(gameVersionLabel)

splash2Container:Visible(false)


local splash2duration = 4.0 --secs
local splash2currentTime = 0

splash2Container:EventFunction(function(self, e, ...)
	if e == UPDATE and splash2Container:IsVisible() then
		splash2currentTime = splash2currentTime + select(1, ...)
		if splash2currentTime >= splash2duration then
			splash2currentTime = 0
			splash2Container:Visible(false)
			menuContainer:Visible(true)
			TriggerEvent(BACK_TO_MENU)
		end
	end	
end)


UIRoot:Attach(splash2Container)
