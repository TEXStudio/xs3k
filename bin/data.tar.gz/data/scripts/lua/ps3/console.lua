--this is the PS3 version
--this file uses components IDs from [16000 to 17000[ and tabindices from [1500 to 1600[

local consoleContainer = CreateFrame("container", "consoleContainer", 16000)
consoleContainer:SetPosition(0.0, 0.0)
consoleContainer:SetSize(2.0, 2.0)
consoleContainer:Renderable(false)
consoleContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)



local consoleTextbox = CreateFrame("textbox", "consoleTextbox", 16100, 1)
consoleTextbox:SetPosition(0.0, 0.0)
consoleTextbox:SetSize(2.0, 2.0)
consoleTextbox:Multiline(true)
consoleTextbox:Wrapping(true)
consoleTextbox:SetLetterHeight(0.04)
consoleTextbox:SetBackgroundColour(0.0, 0.0, 0.0, 0.85)
consoleContainer:Attach(consoleTextbox)


local startShowingConsole = -1
local consoleAnimationStart = 0
local consoleAnimationDuration = 250


consoleTextbox:EventFunction(function(self, e, ...)
	if e == TOGGLE_CONSOLE then
		if consoleContainer:IsVisible() then
			startShowingConsole = -1
			consoleAnimationStart = time("mlsec")
		else
			startShowingConsole = 1
			consoleContainer:SetPosition(0.0, 2.0)
			consoleAnimationStart = time("mlsec")
			consoleContainer:Visible(true)
		end
	end

	if startShowingConsole ~= 0 then
		local t = time("mlsec")
		local fraction = (t-consoleAnimationStart)/(consoleAnimationDuration)
		if fraction >= 1 then 
			if startShowingConsole > 0 then
				consoleContainer:SetPosition(0.0, 0.0)
			else
				consoleContainer:SetPosition(0.0, 2.0)
			end
		elseif fraction <= 0 then 
			if startShowingConsole > 0 then
				consoleContainer:SetPosition(0.0, 2.0)
			else
			consoleContainer:SetPosition(0.0, 0.0)
			end
		else
			if startShowingConsole > 0 then
				consoleContainer:SetPosition(0.0, 2.0*(1-fraction))	
			else
				consoleContainer:SetPosition(0.0, 2.0*(fraction))	
			end
		end
		
		if t >= consoleAnimationStart + consoleAnimationDuration then
			local tempShowingConsole = startShowingConsole
			startShowingConsole = 0
			if tempShowingConsole < 0 then
				consoleContainer:Visible(false)
				TriggerEvent(COMPONENT_REQUEST_FOCUS_PREVIOUS)
			else
				TriggerEvent(UPDATE_LOG)
			end
		end
	end
end)


consoleContainer:Visible(false)
UIRoot:Attach(consoleContainer, 20)