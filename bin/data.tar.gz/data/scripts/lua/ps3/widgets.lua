--this is the PS3 version
--this file uses components IDs from [9000 to 10000[ and tabindices from [800 to 900[
local widgetContainer = CreateFrame("container", "widgetContainer", 9000)
widgetContainer:SetPosition(0.0, 0.0)
widgetContainer:SetSize(2.0, 2.0)
UIRoot:Attach(widgetContainer)

