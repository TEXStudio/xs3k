--this is the PS3 keybindings
--this file uses components IDs from [6000 to 7000[ and tabindices from [500 to 600[

local keybindingsContainer = CreateFrame("container", "keybindingsContainer", 6000)
keybindingsContainer:SetPosition(0.1, 0.05)
keybindingsContainer:SetSize(1.8, 1.4)
keybindingsContainer:Renderable(true)
keybindingsContainer:RenderBorder(true)
keybindingsContainer:SetBackgroundColour(0.66, 0.66, 0.66, 0.35)
keybindingsContainer:SetBorderColour(0.1, 0.1, 0.1, 0.5)
keybindingsContainer:SetBorderThickness(0.02)

local keybindingsContainerGlobalImage = CreateFrame("image", "keybindingsContainerGlobalImage", 6202, 4208)
keybindingsContainerGlobalImage:SetPosition(0.0, 0.0)
keybindingsContainerGlobalImage:SetSize(1.8, 1.4)
keybindingsContainer:Attach(keybindingsContainerGlobalImage)


local keybindingsBackContainer = CreateFrame("container", "keybindingsBackContainer", 6001)
keybindingsBackContainer:SetPosition(0.75, 0.05)
keybindingsBackContainer:SetSize(0.3, 0.15)
local keybindingsBackButton = CreateFrame("button", "keybindingsBackButton", 6300)
keybindingsBackButton:TabIndex(516)
keybindingsBackButton:SetPosition(0.0, 0.0)
keybindingsBackButton:SetSize(keybindingsBackContainer:GetSize())
keybindingsBackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
keybindingsBackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
keybindingsBackContainer:Attach(keybindingsBackButton)
local keybindingsBackImageUP = CreateFrame("image", "keybindingsBackImageUP", 6200, 5204)
keybindingsBackImageUP:SetPosition(0.0, 0.0)
keybindingsBackImageUP:SetSize(keybindingsBackContainer:GetSize())
keybindingsBackContainer:Attach(keybindingsBackImageUP)
local keybindingsBackImageOVER = CreateFrame("image", "keybindingsBackImageOVER", 6201, 5205)
keybindingsBackImageOVER:SetPosition(0.0, 0.0)
keybindingsBackImageOVER:SetSize(keybindingsBackContainer:GetSize())
keybindingsBackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
keybindingsBackContainer:Attach(keybindingsBackImageOVER)
keybindingsContainer:Attach(keybindingsBackContainer)

local controllerKeysXStart = 0.75
local keyTextSize = 0.045
local keyLabelPositionY = keyTextSize/4
local keyLabelDeltaXPosition = 0.1


--this container contains nothing, it's just used to display a background color behind all the controller keys, and i decided to sort things per line and so i can't bind the things to this container
local controllerKeysContainer = CreateFrame("container", "controllerKeysContainer", 6019)
--controllerKeysContainer:SetPosition(pcKeysXStart+0.55, 0.175)
controllerKeysContainer:SetPosition(0.65, 0.3)
controllerKeysContainer:SetSize(0.7, 1.05)
controllerKeysContainer:Renderable(true)
controllerKeysContainer:SetBackgroundColour(0.1, 0.1, 0.1, 1.0)
keybindingsContainer:Attach(controllerKeysContainer)
local controllerKeysContainerImage = CreateFrame("image", "controllerKeysContainerImage", 6204, 4206)
controllerKeysContainerImage:SetPosition(0.0, 0.0)
controllerKeysContainerImage:SetSize(controllerKeysContainer:GetSize())
controllerKeysContainer:Attach(controllerKeysContainerImage)


local keybindHeaderContainer = CreateFrame("container", "keybindHeaderContainer", 6002)
keybindHeaderContainer:SetPosition(0.1, 1.25)
keybindHeaderContainer:SetSize(1.65, 0.1)
keybindingsContainer:Attach(keybindHeaderContainer)
local controllerKeyBindLabel = CreateFrame("label", "controllerKeyBindLabel", 6101, 1)
controllerKeyBindLabel:SetText("Controller")
controllerKeyBindLabel:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)
controllerKeyBindLabel:SetPosition(0.5625, 0.0)
controllerKeyBindLabel:SetSize(0.7, 0.068)
keybindHeaderContainer:Attach(controllerKeyBindLabel)




local whipKeyContainer = CreateFrame("container", "whipKeyContainer", 6003)
whipKeyContainer:SetPosition(0.0, 1.15)
whipKeyContainer:SetSize(1.7, 0.1)
--whipKeyContainer:Renderable(true)
whipKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(whipKeyContainer)
local whipKeyLabel = CreateFrame("label", "whipKeyLabel", 6102, 2)
whipKeyLabel:SetText("Whip")
whipKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
whipKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
whipKeyLabel:SetSize(0.5, 0.07)
whipKeyContainer:Attach(whipKeyLabel)


local whipKeyControllerContainer = CreateFrame("container", "whipKeyControllerContainer", 6005)
whipKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
whipKeyControllerContainer:SetSize(0.5, 0.1)
whipKeyContainer:Attach(whipKeyControllerContainer)
whipKeyControllerButton = CreateFrame("button", "whipKeyControllerButton", 6302)
whipKeyControllerButton:SetSize(whipKeyControllerContainer:GetSize())
whipKeyControllerButton:SetPosition(0.0, 0.0)
whipKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
whipKeyControllerButton:TabIndex(500)
whipKeyControllerContainer:Attach(whipKeyControllerButton)
whipKeyControllerLabel = CreateFrame("label", "whipKeyControllerLabel", 6104, 3)
whipKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
whipKeyControllerLabel:SetSize(select(1, whipKeyControllerContainer:GetSize()), keyTextSize)
whipKeyControllerLabel:SetText("SPACE")
whipKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
whipKeyControllerContainer:Attach(whipKeyControllerLabel)




local treatKeyContainer = CreateFrame("container", "treatKeyContainer", 6006)
treatKeyContainer:SetPosition(0.0, 1.05)
treatKeyContainer:SetSize(whipKeyContainer:GetSize())
--treatKeyContainer:Renderable(true)
treatKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(treatKeyContainer)
local treatKeyLabel = CreateFrame("label", "treatKeyLabel", 6105, 2)
treatKeyLabel:SetText("Treat")
treatKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
treatKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
treatKeyLabel:SetSize(whipKeyLabel:GetSize())
treatKeyContainer:Attach(treatKeyLabel)


local treatKeyControllerContainer = CreateFrame("container", "treatKeyControllerContainer", 6008)
treatKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
treatKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
treatKeyContainer:Attach(treatKeyControllerContainer)
treatKeyControllerButton = CreateFrame("button", "treatKeyControllerButton", 6304)
treatKeyControllerButton:SetSize(treatKeyControllerContainer:GetSize())
treatKeyControllerButton:SetPosition(0.0, 0.0)
treatKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
treatKeyControllerButton:TabIndex(501)
treatKeyControllerContainer:Attach(treatKeyControllerButton)
treatKeyControllerLabel = CreateFrame("label", "treatKeyControllerLabel", 6107, 3)
treatKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
treatKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
treatKeyControllerLabel:SetText("SPACE")
treatKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
treatKeyControllerContainer:Attach(treatKeyControllerLabel)



local brakeKeyContainer = CreateFrame("container", "brakeKeyContainer", 6009)
brakeKeyContainer:SetPosition(0.0, 0.95)
brakeKeyContainer:SetSize(whipKeyContainer:GetSize())
--brakeKeyContainer:Renderable(true)
brakeKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(brakeKeyContainer)
local brakeKeyLabel = CreateFrame("label", "brakeKeyLabel", 6108, 2)
brakeKeyLabel:SetText("Brake")
brakeKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
brakeKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
brakeKeyLabel:SetSize(whipKeyLabel:GetSize())
brakeKeyContainer:Attach(brakeKeyLabel)


local brakeKeyControllerContainer = CreateFrame("container", "brakeKeyControllerContainer", 6011)
brakeKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
brakeKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
brakeKeyContainer:Attach(brakeKeyControllerContainer)
brakeKeyControllerButton = CreateFrame("button", "brakeKeyControllerButton", 6306)
brakeKeyControllerButton:SetSize(brakeKeyControllerContainer:GetSize())
brakeKeyControllerButton:SetPosition(0.0, 0.0)
brakeKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
brakeKeyControllerButton:TabIndex(502)
brakeKeyControllerContainer:Attach(brakeKeyControllerButton)
brakeKeyControllerLabel = CreateFrame("label", "brakeKeyControllerLabel", 6110, 3)
brakeKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
brakeKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
brakeKeyControllerLabel:SetText("SPACE")
brakeKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
brakeKeyControllerContainer:Attach(brakeKeyControllerLabel)



local leftKeyContainer = CreateFrame("container", "leftKeyContainer", 6012)
leftKeyContainer:SetPosition(0.0, 0.85)
leftKeyContainer:SetSize(whipKeyContainer:GetSize())
--leftKeyContainer:Renderable(true)
leftKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(leftKeyContainer)
local leftKeyLabel = CreateFrame("label", "leftKeyLabel", 6111, 2)
leftKeyLabel:SetText("Left")
leftKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
leftKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
leftKeyLabel:SetSize(whipKeyLabel:GetSize())
leftKeyContainer:Attach(leftKeyLabel)


local leftKeyControllerContainer = CreateFrame("container", "leftKeyControllerContainer", 6014)
leftKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
leftKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
leftKeyContainer:Attach(leftKeyControllerContainer)
leftKeyControllerButton = CreateFrame("button", "leftKeyControllerButton", 6308)
leftKeyControllerButton:SetSize(leftKeyControllerContainer:GetSize())
leftKeyControllerButton:SetPosition(0.0, 0.0)
leftKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
leftKeyControllerButton:TabIndex(503)
leftKeyControllerContainer:Attach(leftKeyControllerButton)
leftKeyControllerLabel = CreateFrame("label", "leftKeyControllerLabel", 6113, 3)
leftKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
leftKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
leftKeyControllerLabel:SetText("SPACE")
leftKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
leftKeyControllerContainer:Attach(leftKeyControllerLabel)



local rightKeyContainer = CreateFrame("container", "rightKeyContainer", 6015)
rightKeyContainer:SetPosition(0.0, 0.75)
rightKeyContainer:SetSize(whipKeyContainer:GetSize())
--rightKeyContainer:Renderable(true)
rightKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(rightKeyContainer)
local rightKeyLabel = CreateFrame("label", "rightKeyLabel", 6114, 2)
rightKeyLabel:SetText("Right")
rightKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
rightKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
rightKeyLabel:SetSize(whipKeyLabel:GetSize())
rightKeyContainer:Attach(rightKeyLabel)


local rightKeyControllerContainer = CreateFrame("container", "rightKeyControllerContainer", 6017)
rightKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
rightKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
rightKeyContainer:Attach(rightKeyControllerContainer)
rightKeyControllerButton = CreateFrame("button", "rightKeyControllerButton", 6310)
rightKeyControllerButton:SetSize(rightKeyControllerContainer:GetSize())
rightKeyControllerButton:SetPosition(0.0, 0.0)
rightKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
rightKeyControllerButton:TabIndex(504)
rightKeyControllerContainer:Attach(rightKeyControllerButton)
rightKeyControllerLabel = CreateFrame("label", "rightKeyControllerLabel", 6116, 3)
rightKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
rightKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
rightKeyControllerLabel:SetText("SPACE")
rightKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
rightKeyControllerContainer:Attach(rightKeyControllerLabel)




local previousCameraKeyContainer = CreateFrame("container", "previousCameraKeyContainer", 6020)
previousCameraKeyContainer:SetPosition(0.0, 0.65)
previousCameraKeyContainer:SetSize(whipKeyContainer:GetSize())
--previousCameraKeyContainer:Renderable(true)
previousCameraKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(previousCameraKeyContainer)
local previousCameraKeyLabel = CreateFrame("label", "previousCameraKeyLabel", 6118, 2)
previousCameraKeyLabel:SetText("<cam")
previousCameraKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
previousCameraKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
previousCameraKeyLabel:SetSize(whipKeyLabel:GetSize())
previousCameraKeyContainer:Attach(previousCameraKeyLabel)


local previousCameraKeyControllerContainer = CreateFrame("container", "previousCameraKeyControllerContainer", 6022)
previousCameraKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
previousCameraKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
previousCameraKeyContainer:Attach(previousCameraKeyControllerContainer)
previousCameraKeyControllerButton = CreateFrame("button", "previousCameraKeyControllerButton", 6312)
previousCameraKeyControllerButton:SetSize(previousCameraKeyControllerContainer:GetSize())
previousCameraKeyControllerButton:SetPosition(0.0, 0.0)
previousCameraKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
previousCameraKeyControllerButton:TabIndex(505)
previousCameraKeyControllerContainer:Attach(previousCameraKeyControllerButton)
previousCameraKeyControllerLabel = CreateFrame("label", "previousCameraKeyControllerLabel", 6120, 3)
previousCameraKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
previousCameraKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
previousCameraKeyControllerLabel:SetText("SPACE")
previousCameraKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
previousCameraKeyControllerContainer:Attach(previousCameraKeyControllerLabel)




local nextCameraKeyContainer = CreateFrame("container", "nextCameraKeyContainer", 6023)
nextCameraKeyContainer:SetPosition(0.0, 0.55)
nextCameraKeyContainer:SetSize(whipKeyContainer:GetSize())
--nextCameraKeyContainer:Renderable(true)
nextCameraKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(nextCameraKeyContainer)
local nextCameraKeyLabel = CreateFrame("label", "nextCameraKeyLabel", 6121, 2)
nextCameraKeyLabel:SetText("cam>")
nextCameraKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
nextCameraKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
nextCameraKeyLabel:SetSize(whipKeyLabel:GetSize())
nextCameraKeyContainer:Attach(nextCameraKeyLabel)


local nextCameraKeyControllerContainer = CreateFrame("container", "nextCameraKeyControllerContainer", 6025)
nextCameraKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
nextCameraKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
nextCameraKeyContainer:Attach(nextCameraKeyControllerContainer)
nextCameraKeyControllerButton = CreateFrame("button", "nextCameraKeyControllerButton", 6314)
nextCameraKeyControllerButton:SetSize(nextCameraKeyControllerContainer:GetSize())
nextCameraKeyControllerButton:SetPosition(0.0, 0.0)
nextCameraKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
nextCameraKeyControllerButton:TabIndex(506)
nextCameraKeyControllerContainer:Attach(nextCameraKeyControllerButton)
nextCameraKeyControllerLabel = CreateFrame("label", "nextCameraKeyControllerLabel", 6123, 3)
nextCameraKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
nextCameraKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
nextCameraKeyControllerLabel:SetText("SPACE")
nextCameraKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
nextCameraKeyControllerContainer:Attach(nextCameraKeyControllerLabel)




local unstuckKeyContainer = CreateFrame("container", "unstuckKeyContainer", 6026)
unstuckKeyContainer:SetPosition(0.0, 0.45)
unstuckKeyContainer:SetSize(whipKeyContainer:GetSize())
unstuckKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(unstuckKeyContainer)
local unstuckKeyLabel = CreateFrame("label", "unstuckKeyLabel", 6124, 2)
unstuckKeyLabel:SetText("Reset")
unstuckKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
unstuckKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
unstuckKeyLabel:SetSize(whipKeyLabel:GetSize())
unstuckKeyContainer:Attach(unstuckKeyLabel)

local unstuckKeyControllerContainer = CreateFrame("container", "unstuckKeyControllerContainer", 6028)
unstuckKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
unstuckKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
unstuckKeyContainer:Attach(unstuckKeyControllerContainer)
unstuckKeyControllerButton = CreateFrame("button", "unstuckKeyControllerButton", 6316)
unstuckKeyControllerButton:SetSize(unstuckKeyControllerContainer:GetSize())
unstuckKeyControllerButton:SetPosition(0.0, 0.0)
unstuckKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
unstuckKeyControllerButton:TabIndex(507)
unstuckKeyControllerContainer:Attach(unstuckKeyControllerButton)
unstuckKeyControllerLabel = CreateFrame("label", "unstuckKeyControllerLabel", 6126, 3)
unstuckKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
unstuckKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
unstuckKeyControllerLabel:SetText("SPACE")
unstuckKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
unstuckKeyControllerContainer:Attach(unstuckKeyControllerLabel)



local rearviewKeyContainer = CreateFrame("container", "rearviewKeyContainer", 6029)
rearviewKeyContainer:SetPosition(0.0, 0.35)
rearviewKeyContainer:SetSize(whipKeyContainer:GetSize())
rearviewKeyContainer:SetBackgroundColour(1.0, 0.0, 0.0, 1.0)
keybindingsContainer:Attach(rearviewKeyContainer)
local rearviewKeyLabel = CreateFrame("label", "rearviewKeyLabel", 6127, 2)
rearviewKeyLabel:SetText("RView")
rearviewKeyLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
rearviewKeyLabel:SetPosition(keyLabelDeltaXPosition, 0.0)
rearviewKeyLabel:SetSize(whipKeyLabel:GetSize())
rearviewKeyContainer:Attach(rearviewKeyLabel)

local rearviewKeyControllerContainer = CreateFrame("container", "rearviewKeyControllerContainer", 6031)
rearviewKeyControllerContainer:SetPosition(controllerKeysXStart, 0.0)
rearviewKeyControllerContainer:SetSize(whipKeyControllerContainer:GetSize())
rearviewKeyContainer:Attach(rearviewKeyControllerContainer)
rearviewKeyControllerButton = CreateFrame("button", "rearviewKeyControllerButton", 6318)
rearviewKeyControllerButton:SetSize(rearviewKeyControllerContainer:GetSize())
rearviewKeyControllerButton:SetPosition(0.0, 0.0)
rearviewKeyControllerButton:SetBackgroundColour(0.0, 1.0, 0.0, 0.0)
rearviewKeyControllerButton:TabIndex(508)
rearviewKeyControllerContainer:Attach(rearviewKeyControllerButton)
rearviewKeyControllerLabel = CreateFrame("label", "rearviewKeyControllerLabel", 6129, 3)
rearviewKeyControllerLabel:SetPosition(0.0, keyLabelPositionY)
rearviewKeyControllerLabel:SetSize(whipKeyControllerLabel:GetSize())
rearviewKeyControllerLabel:SetText("SPACE")
rearviewKeyControllerLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
rearviewKeyControllerContainer:Attach(rearviewKeyControllerLabel)



local keybindInfoLabel = CreateFrame("label", "keybindInfoLabel", 6117, 2)
keybindInfoLabel:SetPosition(0.05, 0.25)
keybindInfoLabel:SetSize(1.7, 0.05)
keybindInfoLabel:SetText("")
keybindInfoLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
keybindingsContainer:Attach(keybindInfoLabel)


keybindingsContainer:Visible(false)
UIRoot:Attach(keybindingsContainer)


keybindingButtonCycleStart = { 0.0 }
keybindingButtonCycleDuration = { buttonAnimationCycleDuration }
keybindingButtonCycleDoAnimation = { false }
keybindingButtonCycleAnimationOver = { false }


keybindingsBackButton:EventFunction(function( self, e , ... )
	playDefaultButtonSoundFX(e)
	--swapImages(e, keybindingsBackImageUP, keybindingsBackImageOVER)
	buttonOver(e, 1, keybindingButtonCycleStart, keybindingButtonCycleDuration, keybindingButtonCycleDoAnimation, keybindingButtonCycleAnimationOver, keybindingsBackImageOVER)

	if e == COMPONENT_ACTION_PERFORMED then
		TriggerEvent(CANCEL_KEYBIND_CHANGE)
		keybindInfoLabel:SetText("")
		keybindingsContainer:Visible(false)
		optionsMenuContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, optionsKeyBindingsButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

function keybindingGenericFunction(e, e1, e2, l, t, nk)
	playDefaultButtonSoundFX(e)
	if e == COMPONENT_ACTION_PERFORMED then
		keybindInfoLabel:SetText("Press the new binding for "..t..".")
		TriggerEvent(e1)
	end
	if e == e2 then
		l:SetText(nk)
		keybindInfoLabel:SetText("Successfully rebound "..t..".")
	end
end

keybindInfoLabel:EventFunction(function( self, e , ... )
	if e == KEYBIND_UNBOUND_MESSAGE then
		keybindInfoLabel:SetText(select(1, ...))
	end
end)

whipKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_WHIP_CONTROLLERKEY_REBIND, WHIP_CONTROLLERKEY_REBOUND, whipKeyControllerLabel, "Whip", select(1, ...))
end)

treatKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_TREAT_CONTROLLERKEY_REBIND, TREAT_CONTROLLERKEY_REBOUND, treatKeyControllerLabel, "Treat", select(1, ...))
end)

brakeKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_BRAKE_CONTROLLERKEY_REBIND, BRAKE_CONTROLLERKEY_REBOUND, brakeKeyControllerLabel, "Brake", select(1, ...))
end)

leftKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_LEFT_CONTROLLERKEY_REBIND, LEFT_CONTROLLERKEY_REBOUND, leftKeyControllerLabel, "Left", select(1, ...))
end)

rightKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_RIGHT_CONTROLLERKEY_REBIND, RIGHT_CONTROLLERKEY_REBOUND, rightKeyControllerLabel, "Right", select(1, ...))
end)

previousCameraKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_PREVIOUSCAMERA_CONTROLLERKEY_REBIND, PREVIOUS_CAMERA_CONTROLLERKEY_REBOUND, previousCameraKeyControllerLabel, "<Cam", select(1, ...))
end)

nextCameraKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_NEXTCAMERA_CONTROLLERKEY_REBIND, NEXT_CAMERA_CONTROLLERKEY_REBOUND, nextCameraKeyControllerLabel, "Cam>", select(1, ...))
end)

unstuckKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_RESETPOSITION_CONTROLLERKEY_REBIND, RESET_POSITION_CONTROLLERKEY_REBOUND, unstuckKeyControllerLabel, "Reset", select(1, ...))
end)

rearviewKeyControllerButton:EventFunction(function( self, e , ... )
	keybindingGenericFunction(e, REQUEST_REARVIEW_CONTROLLERKEY_REBIND, REARVIEW_CONTROLLERKEY_REBOUND, rearviewKeyControllerLabel, "RView", select(1, ...))
end)

