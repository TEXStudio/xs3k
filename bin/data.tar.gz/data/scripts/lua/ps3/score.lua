--this is the PS3 version
--this file uses components IDs from [13000 to 14000[ and tabindices from [1200 to 1300[


local scoreContainer = CreateFrame("container", "scoreContainer", 13000)
scoreContainer:SetPosition(0.1, 0.3)
scoreContainer:SetSize(1.8, 1.4)
scoreContainer:Renderable(true)
scoreContainer:RenderBorder(true)
scoreContainer:SetBackgroundColour(0.0, 1.0, 1.0, 0.75)
scoreContainer:SetBorderColour(0.0, 0.0, 0.0, 0.0)

local scoreXPadding = 0.1
local scoreYSpacing = 0.05
local scoreFontSize = 0.06

local scoreContainerGlobalImage = CreateFrame("image", "scoreContainerGlobalImage", 13100, 14100)
scoreContainerGlobalImage:SetSize(scoreContainer:GetSize())
scoreContainerGlobalImage:SetPosition(0.0, 0.0)
scoreContainer:Attach(scoreContainerGlobalImage)

local highscoresTitleLabel = CreateFrame("label", "highscoresTitleLabel", 13211, 2)
highscoresTitleLabel:SetText("HIGHSCORES")
highscoresTitleLabel:SetSize(1.8, 0.1)
highscoresTitleLabel:SetPosition(0.0, 1.2)
highscoresTitleLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
scoreContainer:Attach(highscoresTitleLabel)


local highscoresContainer = CreateFrame("container", "highscoresContainer", 13003)
highscoresContainer:SetSize(select(1, scoreContainer:GetSize())-2*scoreXPadding, 1.0)
highscoresContainer:SetPosition(scoreXPadding, 0.1)
scoreContainer:Attach(highscoresContainer)


firstHighscoreNameLabel = CreateFrame("label", "firstHighscoreLabel", 13205, 2)
firstHighscoreNameLabel:SetText("1. Thomas")
firstHighscoreNameLabel:SetSize(1.1, scoreFontSize)
firstHighscoreNameLabel:SetPosition(0.0, select(2, highscoresContainer:GetSize())-scoreFontSize)
firstHighscoreNameLabel:SetBackgroundColour(1.0, 0.843, 0.0, 1.0)
highscoresContainer:Attach(firstHighscoreNameLabel)
firstHighscoreTimeLabel = CreateFrame("label", "firstHighscoreTimeLabel", 13206, 2)
firstHighscoreTimeLabel:SetText("668:00.9")
firstHighscoreTimeLabel:SetSize(0.5, scoreFontSize)
firstHighscoreTimeLabel:SetPosition(select(1, firstHighscoreNameLabel:GetSize()), select(2, highscoresContainer:GetSize())-scoreFontSize)
firstHighscoreTimeLabel:SetBackgroundColour(1.0, 0.843, 0.0, 1.0)
highscoresContainer:Attach(firstHighscoreTimeLabel)

secondHighscoreNameLabel = CreateFrame("label", "firstHighscoreLabel", 13207, 2)
secondHighscoreNameLabel:SetText("2. Thomas")
secondHighscoreNameLabel:SetSize(1.1, scoreFontSize)
secondHighscoreNameLabel:SetPosition(0.0, select(2, highscoresContainer:GetSize())-2*scoreFontSize)
secondHighscoreNameLabel:SetBackgroundColour(0.75, 0.75, 0.75, 1.0)
highscoresContainer:Attach(secondHighscoreNameLabel)
secondHighscoreTimeLabel = CreateFrame("label", "secondHighscoreTimeLabel", 13208, 2)
secondHighscoreTimeLabel:SetText("999:00.9")
secondHighscoreTimeLabel:SetSize(0.5, scoreFontSize)
secondHighscoreTimeLabel:SetPosition(select(1, secondHighscoreNameLabel:GetSize()), 1.0-2*scoreFontSize)
secondHighscoreTimeLabel:SetBackgroundColour(0.75, 0.75, 0.75, 1.0)
highscoresContainer:Attach(secondHighscoreTimeLabel)

thirdHighscoreNameLabel = CreateFrame("label", "thirdHighscoreNameLabel", 13209, 2)
thirdHighscoreNameLabel:SetText("3. Thomas")
thirdHighscoreNameLabel:SetSize(1.1, scoreFontSize)
thirdHighscoreNameLabel:SetPosition(0.0, select(2, highscoresContainer:GetSize())-3*scoreFontSize)
thirdHighscoreNameLabel:SetBackgroundColour(0.55, 0.47, 0.33, 1.0)
highscoresContainer:Attach(thirdHighscoreNameLabel)
thirdHighscoreTimeLabel = CreateFrame("label", "thirdHighscoreTimeLabel", 13210, 2)
thirdHighscoreTimeLabel:SetText("999:00.9")
thirdHighscoreTimeLabel:SetSize(0.5, scoreFontSize)
thirdHighscoreTimeLabel:SetPosition(select(1, thirdHighscoreNameLabel:GetSize()), select(2, highscoresContainer:GetSize())-3*scoreFontSize)
thirdHighscoreTimeLabel:SetBackgroundColour(0.55, 0.47, 0.33, 1.0)
highscoresContainer:Attach(thirdHighscoreTimeLabel)


local scorePlayerRank = CreateFrame("label", "scorePlayerRank", 13220, 2)
scorePlayerRank:SetText("Your Position:")
scorePlayerRank:SetSize(1.1, scoreFontSize)
scorePlayerRank:SetPosition(0.0, select(2, highscoresContainer:GetSize())-6*scoreFontSize)
scorePlayerRank:SetBackgroundColour(0.0, 0.0, 1.0, 0.0)
highscoresContainer:Attach(scorePlayerRank)
local scorePlayerRankText = CreateFrame("label", "scorePlayerRankText", 13221, 2)
scorePlayerRankText:SetText("1")
scorePlayerRankText:SetSize(0.5, scoreFontSize)
scorePlayerRankText:SetPosition(select(1, scorePlayerRank:GetSize()), select(2, highscoresContainer:GetSize())-6*scoreFontSize)
scorePlayerRankText:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)
highscoresContainer:Attach(scorePlayerRankText)

local scorePlayerBestLapLabel = CreateFrame("label", "scorePlayerBestLapLabel", 13200, 2)
scorePlayerBestLapLabel:SetText("Your Best Lap:")
scorePlayerBestLapLabel:SetSize(1.1, scoreFontSize)
scorePlayerBestLapLabel:SetPosition(0.0, select(2, highscoresContainer:GetSize())-7*scoreFontSize)
scorePlayerBestLapLabel:SetBackgroundColour(0.0, 0.0, 1.0, 0.0)
highscoresContainer:Attach(scorePlayerBestLapLabel)
local scorePlayerBestLapDataLabel = CreateFrame("label", "scorePlayerBestLapDataLabel", 13201, 2)
scorePlayerBestLapDataLabel:SetText("999:00.9")
scorePlayerBestLapDataLabel:SetSize(0.5, scoreFontSize)
scorePlayerBestLapDataLabel:SetPosition(select(1, scorePlayerBestLapLabel:GetSize()), select(2, highscoresContainer:GetSize())-7*scoreFontSize)
scorePlayerBestLapDataLabel:SetBackgroundColour(1.0, 0.0, 0.0, 0.0)
highscoresContainer:Attach(scorePlayerBestLapDataLabel)



local scoreBackToMenuContainer = CreateFrame("container", "scoreBackToMenuContainer", 13002)
scoreBackToMenuContainer:SetSize(0.6, 0.3)
scoreBackToMenuContainer:SetPosition((select(1, scoreContainer:GetSize())-select(1, scoreBackToMenuContainer:GetSize()))/2.0, 0.15)
local scoreBackToMenuImageUp = CreateFrame("image", "scoreBackToMenuImageUp", 13101, 13101)
scoreBackToMenuImageUp:SetPosition(0.0, 0.0)
scoreBackToMenuImageUp:SetSize(scoreBackToMenuContainer:GetSize())
local scoreBackToMenuImageOver = CreateFrame("image", "scoreBackToMenuImageOver", 13102, 13102)
scoreBackToMenuImageOver:SetPosition(0.0, 0.0)
scoreBackToMenuImageOver:SetSize(scoreBackToMenuContainer:GetSize())
scoreBackToMenuImageOver:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
local scoreBackToMenuButton = CreateFrame("button", "scoreBackToMenuButton", 13400)
scoreBackToMenuButton:TabIndex(1201)
scoreBackToMenuButton:SetSize(scoreBackToMenuContainer:GetSize())
scoreBackToMenuButton:SetPosition(0.0, 0.0)
scoreBackToMenuButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
scoreBackToMenuButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
scoreBackToMenuContainer:Attach(scoreBackToMenuButton)
scoreBackToMenuContainer:Attach(scoreBackToMenuImageUp)
scoreBackToMenuContainer:Attach(scoreBackToMenuImageOver)
scoreContainer:Attach(scoreBackToMenuContainer)


scoreMenuButtonCycleStart = { 0.0, 0.0, 0.0, 0.0 }
scoreMenuButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
scoreMenuButtonCycleDoAnimation = { false, false, false, false }
scoreMenuButtonCycleAnimationOver = { false, false, false, false }


ourBestRecord = 9999

scoreBackToMenuButton:EventFunction(function(self, e, ...)
	buttonOver(e, 1, scoreMenuButtonCycleStart, scoreMenuButtonCycleDuration, scoreMenuButtonCycleDoAnimation, scoreMenuButtonCycleAnimationOver, scoreBackToMenuImageOver)
	if e == COMPONENT_ACTION_PERFORMED then
		TriggerEvent(SCENE_QUIT)
	end
end)

local player_position = 1
local score_player_finished = 0

scoreContainer:EventFunction(function(self, e, ...)
	if e == SCENE_FINISHED then
		score_player_finished = select(3,...)
		player_position = select(4,...)
		ourBestRecord = select(5, ...)
		--local bestAllTimeRecord = select(6, ...)

		local minutes, seconds, remainingMilliseconds = formatMilliseconds(ourBestRecord)
		local secondsPadding = ""
		if seconds < 0 then seconds = 0
		elseif seconds < 10 then secondsPadding = "0" end

		if score_player_finished == 1 then 
			if ourBestRecord < rank1bestTime then
				firstHighscoreTimeLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
			elseif ourBestRecord < rank2bestTime then
				secondHighscoreTimeLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
			elseif ourBestRecord < rank3bestTime then
				thirdHighscoreTimeLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)
			end
		end


		scorePlayerRankText:SetText(tostring(player_position))

		scorePlayerBestLapDataLabel:SetText(minutes..":"..secondsPadding..seconds.."."..remainingMilliseconds)

		pauseContainer:Visible(false)
		scoreContainer:Visible(true)
		if cursorWidgetImage ~= nil then cursorWidgetImage:Visible(true) end
		TriggerEvent(COMPONENT_REQUEST_FOCUS, scoreBackToMenuButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

scoreContainer:Visible(false)
UIRoot:Attach(scoreContainer, 10)
