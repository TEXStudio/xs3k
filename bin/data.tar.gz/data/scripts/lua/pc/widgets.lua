--this is the PC version
--this file uses components IDs from [9000 to 10000[ and tabindices from [800 to 900[
local widgetContainer = CreateFrame("container", "widgetContainer", 9000)
widgetContainer:SetPosition(0.0, 0.0)
widgetContainer:SetSize(2.0, 2.0)
--UIRoot:Attach(widgetContainer, 100)


local cursorWidgetImage = CreateFrame("image", "cursorWidgetImage", 9100, 9100)
cursorWidgetImage:SetSize(0.1*9/16.0, 0.1)
--widgetContainer:Attach(cursorWidgetImage)
UIRoot:Attach(cursorWidgetImage, 100)

cursorWidgetImage:EventFunction(function( self, e , ... )
	if UIMANAGER_MOUSE_MOVED then
		local _x = select(3, ...)
		local _y = select(4, ...)
		if _x ~= nil and _y ~= nil then
			if _x < 0.95 and _y < 0.95 then	
				--many magic numbers
				_x = 1 + _x - 0.01*(9/16.0)/2
				_y = 1 + _y - 0.11*(16.0/9)/2
				cursorWidgetImage:SetPosition(_x, _y)
			end
		end
	end
end)