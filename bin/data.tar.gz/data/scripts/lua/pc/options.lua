--this is the PC options
--this file uses components IDs from [4000 to 5000[ and tabindices from [300 to 400[
local optionsMenuContainer = CreateFrame("container", "optionsMenuContainer", 4000)
optionsMenuContainer:SetPosition(0.1, 0.05)
optionsMenuContainer:SetSize(1.8, 1.4)
optionsMenuContainer:Renderable(true)
optionsMenuContainer:RenderBorder(true)
optionsMenuContainer:SetBackgroundColour(0.66, 0.66, 0.66, 0.35)
optionsMenuContainer:SetBorderColour(0.1, 0.1, 0.1, 0.5)
optionsMenuContainer:SetBorderThickness(0.02)

local optionsContainerGlobalImage = CreateFrame("image", "optionsContainerGlobalImage", 4208, 4208)
optionsContainerGlobalImage:SetPosition(0.0, 0.0)
optionsContainerGlobalImage:SetSize(1.8, 1.4)
optionsMenuContainer:Attach(optionsContainerGlobalImage)



local optionsTitleLabel = CreateFrame("label", "optionsTitleLabel", 4100, 3)
optionsTitleLabel:SetText("OPTIONS")
optionsTitleLabel:SetBorderColour(0, 0, 0, 0)
optionsTitleLabel:SetSize(0.65, 0.09)
optionsTitleLabel:SetPosition(0.9-select(1, optionsTitleLabel:GetSize())/2 , 1.28)
optionsTitleLabel:SetBackgroundColour(0.0, 0.0, 0.0, 1.0)
optionsMenuContainer:Attach(optionsTitleLabel)

local videoStartX = 1.05
local soundStartX = 0.1

local sliderImageExtraWidth = 0.05
local sliderImageFocusGainedAlpha = 1.0
local sliderImageFocusLostAlpha = 0.2


local optionTextLevel2Size = 0.06
local optionTextLevel3Size = 0.05
local optionTextLevel4Size = 0.04
local optionSlidersWidth = 0.5
local optionsContainerSlotsWidth = 0.65


local optionsVideoContainer = CreateFrame("container", "optionsVideoContainer", 4009)
optionsVideoContainer:SetPosition(videoStartX, 0.35)
optionsVideoContainer:SetSize(optionsContainerSlotsWidth, 0.9)
optionsVideoContainer:Renderable(true)
--optionsVideoContainer:SetBackgroundColour(0.05, 0.05, 0.05, 1.0)
optionsVideoContainer:SetBackgroundColour(0.0, 0.0, 0.0, 1)
optionsMenuContainer:Attach(optionsVideoContainer)
local optionsVideoContainerImage = CreateFrame("image", "optionsVideoContainerImage", 4206, 4206)
optionsVideoContainerImage:SetPosition(0.0, 0.0)
optionsVideoContainerImage:SetSize(optionsContainerSlotsWidth, 0.9)
--optionsVideoContainerImage:SetBackgroundColour(0.0, 0.0, 0.0, 0.15)
optionsVideoContainer:Attach(optionsVideoContainerImage)


local videoTitleLabel = CreateFrame("label", "videoTitleLabel", 4101, 1)
videoTitleLabel:SetText("VIDEO")
videoTitleLabel:SetBorderColour(0, 0, 0, 0)
videoTitleLabel:SetSize(0.45, optionTextLevel2Size)
videoTitleLabel:SetPosition(select(1, videoTitleLabel:GetSize())/4, 0.8)
videoTitleLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsVideoContainer:Attach(videoTitleLabel)

local resolutionContainer = CreateFrame("container", "resolutionContainer", 4001)
resolutionContainer:SetPosition(0, 0.5)
resolutionContainer:SetSize(optionsContainerSlotsWidth, 0.3)
optionsVideoContainer:Attach(resolutionContainer)

local resolutionLabel = CreateFrame("label", "resolutionLabel", 4104, 1)
resolutionLabel:SetText("RESOLUTION")
resolutionLabel:SetBorderColour(0, 0, 0, 0)
resolutionLabel:SetPosition(0.0, 0.2)
resolutionLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
resolutionLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
resolutionContainer:Attach(resolutionLabel)

local resolutionSliderImage = CreateFrame("image", "resolutionSliderImage", 4212, 4209)
resolutionSliderImage:SetPosition(0.05, 0.1)
resolutionSliderImage:SetSize(optionSlidersWidth+sliderImageExtraWidth, 0.1)
resolutionSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
resolutionContainer:Attach(resolutionSliderImage)
local resolutionSlider = CreateFrame("slider", "resolutionSlider", 4400, 0, 1, RESOLUTIONS_COUNT) 
resolutionSlider:SetValue(options_state["resolution"])
resolutionSlider:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
resolutionSlider:SetPosition(0.05+sliderImageExtraWidth/2, 0.1)
resolutionSlider:SetSize(optionSlidersWidth, 0.1)
resolutionSlider:TabIndex(302)
resolutionSlider:SetBackgroundColour(0.5, 0.5, 0.5, 0.0)
resolutionSlider:SetBorderColour(0.15, 0.15, 0.15, 0.0)
resolutionSlider:Enabled(not options_state["fullscreen"])
resolutionContainer:Attach(resolutionSlider)

local resolutionSliderLabel = CreateFrame("label", "resolutionSliderLabel", 4105, 1)
resolutionSliderLabel:SetText(tostring(options_resolutions[resolutionSlider:GetValue()]))
resolutionSliderLabel:SetPosition(0.0, optionTextLevel3Size/2)
resolutionSliderLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
resolutionSliderLabel:SetBorderColour(0, 0, 0, 0)
resolutionSliderLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
resolutionContainer:Attach(resolutionSliderLabel)

local qualityContainer = CreateFrame("container", "qualityContainer", 4003)
qualityContainer:SetPosition(0.0, 0.175)
qualityContainer:SetSize(optionsContainerSlotsWidth, 0.3)
optionsVideoContainer:Attach(qualityContainer)

local qualityLabel = CreateFrame("label", "qualityLabel", 4108, 1)
qualityLabel:SetText("QUALITY")
qualityLabel:SetBorderColour(0, 0, 0, 0)
qualityLabel:SetPosition(0.0, 0.2)
qualityLabel:SetSize(0.65, optionTextLevel3Size)
qualityLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
qualityContainer:Attach(qualityLabel)

local qualitySliderImage = CreateFrame("image", "soundSliderImage", 4211, 4209)
qualitySliderImage:SetPosition(0.05, 0.1)
qualitySliderImage:SetSize(optionSlidersWidth+sliderImageExtraWidth, 0.1)
qualitySliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
qualityContainer:Attach(qualitySliderImage)
local qualitySlider = CreateFrame("slider", "qualitySlider", 4402, 0, 1, 2) 
qualitySlider:SetValue(options_state["quality"])
qualitySlider:SetPosition(0.05+sliderImageExtraWidth/2, 0.1)
qualitySlider:SetSize(optionSlidersWidth, 0.1)
qualitySlider:TabIndex(303)
qualitySlider:SetBackgroundColour(0.5, 0.5, 0.5, 0.0)
qualitySlider:SetBorderColour(0.0, 0.0, 0.0, 0.0)
qualitySlider:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
qualityContainer:Attach(qualitySlider)

local qualitySliderLabel = CreateFrame("label", "qualitySliderLabel", 4109, 1)
qualitySliderLabel:SetText(tostring(options_qualities[qualitySlider:GetValue()]))
qualitySliderLabel:SetPosition(0.0, 0.0)
qualitySliderLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
qualitySliderLabel:SetBorderColour(0, 0, 0, 0)
qualitySliderLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
qualityContainer:Attach(qualitySliderLabel)


local optionsFullscreenContainer = CreateFrame("container", "optionsFullscreenContainer", 4008)
optionsFullscreenContainer:SetPosition(0.0, 0.0)
optionsFullscreenContainer:SetSize(optionsContainerSlotsWidth, 0.17)
optionsFullscreenContainer:Renderable(false)
optionsFullscreenContainer:SetBackgroundColour(0.0, 1.0, 0.0, 1.0)
optionsVideoContainer:Attach(optionsFullscreenContainer)
local optionsFullscreenLabel = CreateFrame("label", "optionsFullscreenLabel", 4113, 1)
optionsFullscreenLabel:SetText("Fullscreen")
optionsFullscreenLabel:SetSize(optionsContainerSlotsWidth-0.08, optionTextLevel3Size)
optionsFullscreenLabel:SetPosition(0.0, 0.05)
optionsFullscreenLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsFullscreenContainer:Attach(optionsFullscreenLabel)
local optionsFullscreenCheckbox = CreateFrame("checkbox", "optionsFullscreenCheckbox", 4500)
optionsFullscreenCheckbox:SetChecked(options_state["fullscreen"])
optionsFullscreenCheckbox:SetBackgroundColour(0.1, 0.1, 0.1, 1.0)
optionsFullscreenCheckbox:SetSize(0.08, 0.08)
optionsFullscreenCheckbox:SetPosition(0.55, 0.0375)
optionsFullscreenCheckbox:SetPixelSize(0.005)
optionsFullscreenCheckbox:SetBorderColour(1.0, 1.0, 1.0, 1.0)
optionsFullscreenCheckbox:SetBorderThickness(0.005)
optionsFullscreenCheckbox:TabIndex(304)
optionsFullscreenContainer:Attach(optionsFullscreenCheckbox)

local optionsSoundContainer = CreateFrame("container", "optionsSoundContainer", 4010)
optionsSoundContainer:SetPosition(soundStartX, 0.35)
optionsSoundContainer:SetSize(optionsContainerSlotsWidth, 0.9)
optionsSoundContainer:Renderable(true)
optionsSoundContainer:SetBackgroundColour(0.0, 0.0, 0.0, 1)
optionsMenuContainer:Attach(optionsSoundContainer)
local optionsSoundContainerImage = CreateFrame("image", "optionsSoundContainerImage", 4207, 4206)
optionsSoundContainerImage:SetPosition(0.0, 0.0)
optionsSoundContainerImage:SetSize(optionsContainerSlotsWidth, 0.9)
optionsSoundContainer:Attach(optionsSoundContainerImage)


local soundTitleLabel = CreateFrame("label", "soundTitleLabel", 4102, 1)
soundTitleLabel:SetText("SOUND")
soundTitleLabel:SetBorderColour(0, 0, 0, 0)
soundTitleLabel:SetSize(0.45, optionTextLevel2Size)
soundTitleLabel:SetPosition(select(1, soundTitleLabel:GetSize())/4, 0.8)
soundTitleLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsSoundContainer:Attach(soundTitleLabel)

local musicContainer = CreateFrame("container", "musicContainer", 4002)
musicContainer:SetPosition(0, 0.5)
musicContainer:SetSize(optionsContainerSlotsWidth, 0.3)
optionsSoundContainer:Attach(musicContainer)

local musicLabel = CreateFrame("label", "musicLabel", 4106, 1)
musicLabel:SetText("MUSIC")
musicLabel:SetBorderColour(0, 0, 0, 0)
musicLabel:SetPosition(0.0, 0.2)
musicLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
musicLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
musicContainer:Attach(musicLabel)

local musicSliderImage = CreateFrame("image", "musicSliderImage", 4210, 4209)
musicSliderImage:SetPosition(0.05, 0.1)
musicSliderImage:SetSize(optionSlidersWidth+sliderImageExtraWidth, 0.1)
musicSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
musicContainer:Attach(musicSliderImage)
local musicSlider = CreateFrame("slider", "musicSlider", 4401, 50, 0, 100) --0% to 100%
musicSlider:SetValue(options_state["music"])
musicSlider:SetPosition(0.05+sliderImageExtraWidth/2, 0.1)
musicSlider:SetSize(optionSlidersWidth, 0.1)
musicSlider:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
musicSlider:TabIndex(300)
musicSlider:SetBackgroundColour(0.5, 0.5, 0.5, 0.0)
musicSlider:SetBorderColour(0.15, 0.15, 0.15, 0.0)
musicContainer:Attach(musicSlider)

local musicSliderLabel = CreateFrame("label", "musicSliderLabel", 4107, 1)
musicSliderLabel:SetText(musicSlider:GetValue().."%")
musicSliderLabel:SetPosition(0.0, 0.0)
musicSliderLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
musicSliderLabel:SetBorderColour(0, 0, 0, 0)
musicSliderLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
musicContainer:Attach(musicSliderLabel)


local soundContainer = CreateFrame("container", "soundContainer", 4004)
soundContainer:SetPosition(0.0, 0.175)
soundContainer:SetSize(optionsContainerSlotsWidth, 0.3)
optionsSoundContainer:Attach(soundContainer)

local soundLabel = CreateFrame("label", "soundLabel", 4110, 1)
soundLabel:SetText("SOUND FX")
soundLabel:SetBorderColour(0, 0, 0, 0)
soundLabel:SetPosition(0.0, 0.2)
soundLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
soundLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
soundContainer:Attach(soundLabel)

local soundSliderImage = CreateFrame("image", "soundSliderImage", 4209, 4209)
soundSliderImage:SetPosition(0.05, 0.1)
soundSliderImage:SetSize(optionSlidersWidth+sliderImageExtraWidth, 0.1)
soundSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
soundContainer:Attach(soundSliderImage)
local soundSlider = CreateFrame("slider", "soundSlider", 4403, 50, 0, 100) --0% to 100%
soundSlider:SetValue(options_state["sound"])
soundSlider:SetPosition(0.05+sliderImageExtraWidth/2, 0.1)
soundSlider:SetSize(optionSlidersWidth, 0.1)
soundSlider:TabIndex(301)
soundSlider:SetBackgroundColour(0.5, 0.5, 0.5, 0.0)
soundSlider:SetBorderColour(0.0, 0.0, 0.0, 0.0)
soundSlider:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
soundContainer:Attach(soundSlider)

local soundSliderLabel = CreateFrame("label", "soundSliderLabel", 4111, 1)
soundSliderLabel:SetText(soundSlider:GetValue().."%")
soundSliderLabel:SetPosition(0.0, 0.0)
soundSliderLabel:SetSize(optionsContainerSlotsWidth, optionTextLevel3Size)
soundSliderLabel:SetBorderColour(0, 0, 0, 0)
soundSliderLabel:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
soundContainer:Attach(soundSliderLabel)


local optionsKeyBindingsContainer = CreateFrame("container", "optionsKeyBindingsContainer", 4007)
optionsKeyBindingsContainer:SetSize(0.3, 0.15)
optionsKeyBindingsContainer:SetPosition((select(1, optionsMenuContainer:GetSize())-select(1, optionsKeyBindingsContainer:GetSize()))/2, 0.05)
optionsMenuContainer:Attach(optionsKeyBindingsContainer)
local optionsKeyBindingsButton = CreateFrame("button", "optionsKeyBindingsButton", 4302)
optionsKeyBindingsButton:SetBackgroundColour(0.1, 0.1, 0.1, 0.0)
optionsKeyBindingsButton:SetSize(0.3, 0.15)
optionsKeyBindingsButton:SetPosition(0.0, 0.0)
optionsKeyBindingsButton:TabIndex(305)
optionsKeyBindingsButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
optionsKeyBindingsContainer:Attach(optionsKeyBindingsButton)
local optionsKeybindingsImageUP = CreateFrame("image", "optionsKeybindingsImageUP", 4204, 4204)
optionsKeybindingsImageUP:SetPosition(0.0, 0.0)
optionsKeybindingsImageUP:SetSize(0.3, 0.15)
optionsKeyBindingsContainer:Attach(optionsKeybindingsImageUP)
local optionsKeybindingsImageOVER = CreateFrame("image", "optionsKeybindingsImageOVER", 4205, 4205)
optionsKeybindingsImageOVER:SetPosition(0.0, 0.0)
optionsKeybindingsImageOVER:SetSize(0.3, 0.15)
optionsKeybindingsImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsKeyBindingsContainer:Attach(optionsKeybindingsImageOVER)


local optionsBackContainer = CreateFrame("container", "optionsBackContainer", 4005)
optionsBackContainer:SetSize(0.3, 0.15)
--optionsBackContainer:SetPosition((select(1, optionsMenuContainer:GetSize())-nextAndBackDistance)/2-select(1, optionsBackContainer:GetSize()), 0.05)
optionsBackContainer:SetPosition((select(1, optionsMenuContainer:GetSize())-select(1, optionsKeyBindingsContainer:GetSize()))/2 - select(1, optionsKeyBindingsContainer:GetSize()) - nextAndBackDistance, 0.05)
local optionsBackButton = CreateFrame("button", "optionsBackButton", 4300)
optionsBackButton:TabIndex(306)
optionsBackButton:SetPosition(0.0, 0.0)
optionsBackButton:SetSize(optionsBackContainer:GetSize())
optionsBackButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
optionsBackButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsBackContainer:Attach(optionsBackButton)
local optionsBackImageUP = CreateFrame("image", "optionsBackImageUP", 4200, 4200)
optionsBackImageUP:SetPosition(0.0, 0.0)
optionsBackImageUP:SetSize(optionsBackContainer:GetSize())
optionsBackContainer:Attach(optionsBackImageUP)
local optionsBackImageOVER = CreateFrame("image", "optionsBackImageOVER", 4201, 4201)
optionsBackImageOVER:SetPosition(0.0, 0.0)
optionsBackImageOVER:SetSize(optionsBackContainer:GetSize())
optionsBackImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsBackContainer:Attach(optionsBackImageOVER)
optionsMenuContainer:Attach(optionsBackContainer)


local optionsCancelContainer = CreateFrame("container", "optionsCancelContainer", 4006)
optionsCancelContainer:SetSize(0.3, 0.15)
--optionsCancelContainer:SetPosition((select(1, optionsMenuContainer:GetSize())+nextAndBackDistance)/2, 0.05)
optionsCancelContainer:SetPosition((select(1, optionsMenuContainer:GetSize())-select(1, optionsKeyBindingsContainer:GetSize()))/2 + select(1, optionsKeyBindingsContainer:GetSize()) + nextAndBackDistance, 0.05)
local optionsCancelButton = CreateFrame("button", "optionsCancelButton", 4301)
optionsCancelButton:TabIndex(307)
optionsCancelButton:SetPosition(0.0, 0.0)
optionsCancelButton:SetSize(optionsCancelContainer:GetSize())
optionsCancelButton:SetBorderColour(0.0, 0.0, 0.0, 0.0)
optionsCancelButton:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsCancelContainer:Attach(optionsCancelButton)
local optionsCancelImageUP = CreateFrame("image", "optionsCancelImageUP", 4202, 4202)
optionsCancelImageUP:SetPosition(0.0, 0.0)
optionsCancelImageUP:SetSize(optionsCancelContainer:GetSize())
optionsCancelContainer:Attach(optionsCancelImageUP)
local optionsCancelImageOVER = CreateFrame("image", "optionsCancelImageOVER", 4203, 4203)
optionsCancelImageOVER:SetPosition(0.0, 0.0)
optionsCancelImageOVER:SetSize(optionsCancelContainer:GetSize())
optionsCancelImageOVER:SetBackgroundColour(0.0, 0.0, 0.0, 0.0)
optionsCancelContainer:Attach(optionsCancelImageOVER)
optionsMenuContainer:Attach(optionsCancelContainer)


optionsMenuContainer:Visible(false)
UIRoot:Attach(optionsMenuContainer)

optionButtonCycleStart = { 0.0, 0.0, 0.0 }
optionButtonCycleDuration = { buttonAnimationCycleDuration, buttonAnimationCycleDuration, buttonAnimationCycleDuration }
optionButtonCycleDoAnimation = { false, false, false }
optionButtonCycleAnimationOver = { false, false, false }

optionsKeyBindingsButton:EventFunction(function( self, e , ... )
	playDefaultButtonSoundFX(e)
	--swapImages(e, optionsKeybindingsImageUP, optionsKeybindingsImageOVER)
	buttonOver(e, 1, optionButtonCycleStart, optionButtonCycleDuration, optionButtonCycleDoAnimation, optionButtonCycleAnimationOver, optionsKeybindingsImageOVER)

	if e == COMPONENT_ACTION_PERFORMED then
		keybindInfoLabel:SetText("")
		optionsMenuContainer:Visible(false)
		keybindingsContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, whipKeyPCButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

optionsFullscreenCheckbox:EventFunction(function( self, e , ... )
	if e == COMPONENT_ACTION_PERFORMED then
		local value = resolutionSlider:GetValue()
		local fullscreenzor = 0
		if optionsFullscreenCheckbox:IsChecked() then
			fullscreenzor = 1;
			resolutionSlider:Enabled(false)
		else
			resolutionSlider:Enabled(true)
		end
		TriggerEvent(RESIZE_WINDOWS, value+UIMANAGER_FROM_LUA_BIAS, fullscreenzor+UIMANAGER_FROM_LUA_BIAS)
	end
end)

resolutionSlider:EventFunction(function( self, e , ... )
	if e == COMPONENT_ON_FOCUS_GAINED then
		resolutionSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusGainedAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusGainedAlpha)
	elseif e == COMPONENT_ON_FOCUS_LOST then
		resolutionSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
	elseif e == COMPONENT_ON_VALUE_CHANGED then
		local value = tonumber(select(5, ...))
		resolutionSliderLabel:SetText(options_resolutions[value])

		local fullscreenzor = 0
		if optionsFullscreenCheckbox:IsChecked() then
			fullscreenzor = 1
		end
		TriggerEvent(RESIZE_WINDOWS, value+UIMANAGER_FROM_LUA_BIAS, fullscreenzor+UIMANAGER_FROM_LUA_BIAS)
	end
end)

qualitySlider:EventFunction(function( self, e , ... )
	if e == COMPONENT_ON_FOCUS_GAINED then
		qualitySliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusGainedAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusGainedAlpha)
	elseif e == COMPONENT_ON_FOCUS_LOST then
		qualitySliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
	elseif e == COMPONENT_ON_VALUE_CHANGED then
		local value = tonumber(select(5, ...))
		qualitySliderLabel:SetText(options_qualities[value])
	end
end)

musicSlider:EventFunction(function( self, e , ... )
	if e == COMPONENT_ON_FOCUS_GAINED then
		musicSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusGainedAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusGainedAlpha)
	elseif e == COMPONENT_ON_FOCUS_LOST then
		musicSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
	elseif e == COMPONENT_ON_VALUE_CHANGED then
		local value = tonumber(select(5, ...))
		musicSliderLabel:SetText(value .. "%")
		TriggerEvent(SET_MUSIC_VOLUME, value+UIMANAGER_FROM_LUA_BIAS)
	end
end)

soundSlider:EventFunction(function( self, e , ... )
	if e == COMPONENT_ON_FOCUS_GAINED then
		soundSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusGainedAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusGainedAlpha)
	elseif e == COMPONENT_ON_FOCUS_LOST then
		soundSliderImage:SetBackgroundColour(0.0, 0.0, 0.0, sliderImageFocusLostAlpha)
		self:SetMarkerColour(1.0, 1.0, 1.0, sliderImageFocusLostAlpha)
	elseif e == COMPONENT_ON_VALUE_CHANGED then
		local value = tonumber(select(5, ...))
		soundSliderLabel:SetText(value .. "%")
		TriggerEvent(SET_SOUND_VOLUME, value+UIMANAGER_FROM_LUA_BIAS)
	end
end)

optionsBackButton:EventFunction(function( self, e , ... )
	playDefaultButtonSoundFX(e)
	--swapImages(e, optionsBackImageUP, optionsBackImageOVER)
	buttonOver(e, 2, optionButtonCycleStart, optionButtonCycleDuration, optionButtonCycleDoAnimation, optionButtonCycleAnimationOver, optionsBackImageOVER)

	if e == COMPONENT_ACTION_PERFORMED then
		--save
		options_state["resolution"] = resolutionSlider:GetValue()
		options_state["quality"] = qualitySlider:GetValue()
		options_state["music"] = musicSlider:GetValue()
		options_state["sound"] = soundSlider:GetValue()
		options_state["fullscreen"] = optionsFullscreenCheckbox:IsChecked()

		previous_music_volume = options_state["music"]
		previous_sound_volume = options_state["sound"]


		local fullscreenzor = 0
		if options_state["fullscreen"] then
			fullscreenzor = 1;
		end
		TriggerEvent(SAVE_OPTIONS, options_state["resolution"]+UIMANAGER_FROM_LUA_BIAS, options_state["quality"]+UIMANAGER_FROM_LUA_BIAS, options_state["music"]+UIMANAGER_FROM_LUA_BIAS, options_state["sound"]+UIMANAGER_FROM_LUA_BIAS, fullscreenzor+UIMANAGER_FROM_LUA_BIAS)
		--navigate
		optionsMenuContainer:Visible(false)
		menuContainer:Visible(true)
		menuUIStuffContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, optionsButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)

optionsCancelButton:EventFunction(function( self, e , ... )
	playDefaultButtonSoundFX(e)
	--swapImages(e, optionsCancelImageUP, optionsCancelImageOVER)
	buttonOver(e, 3, optionButtonCycleStart, optionButtonCycleDuration, optionButtonCycleDoAnimation, optionButtonCycleAnimationOver, optionsCancelImageOVER)
	if e == COMPONENT_ACTION_PERFORMED then
		--backup
		resolutionSlider:SetValue(options_state["resolution"])
		qualitySlider:SetValue(options_state["quality"])
				
		optionsFullscreenCheckbox:SetChecked(options_state["fullscreen"])

		musicSlider:SetValue(previous_music_volume)
		soundSlider:SetValue(previous_sound_volume)

		options_state["music"] = previous_music_volume
		options_state["sound"] = previous_sound_volume



		local value = options_state["resolution"]
		local fullscreenzor = 0
		if optionsFullscreenCheckbox:IsChecked() then
			fullscreenzor = 1;
		end
		TriggerEvent(RESIZE_WINDOWS, value+UIMANAGER_FROM_LUA_BIAS, fullscreenzor+UIMANAGER_FROM_LUA_BIAS)




		TriggerEvent(CANCEL_OPTIONS)
		--navigate
		optionsMenuContainer:Visible(false)
		menuContainer:Visible(true)
		menuUIStuffContainer:Visible(true)
		TriggerEvent(COMPONENT_REQUEST_FOCUS, optionsButton:GetId()+UIMANAGER_FROM_LUA_BIAS)
	end
end)